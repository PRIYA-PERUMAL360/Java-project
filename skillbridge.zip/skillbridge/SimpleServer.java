import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;
import java.io.*;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.file.Files;
import java.util.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Random;
import java.text.SimpleDateFormat;

public class SimpleServer {
    
    // ==================== DATABASE STORAGE ====================
    static Map<String, User> users = new ConcurrentHashMap<>();
    static Map<Integer, Course> courses = new ConcurrentHashMap<>();
    static Map<Integer, List<Review>> reviews = new ConcurrentHashMap<>();
    static Map<String, List<Payment>> payments = new ConcurrentHashMap<>();
    static Map<String, List<Certificate>> certificates = new ConcurrentHashMap<>();
    static Map<String, List<ChatMessage>> chats = new ConcurrentHashMap<>();
    static Map<String, List<Booking>> bookings = new ConcurrentHashMap<>();
    static Map<String, List<Skill>> skills = new ConcurrentHashMap<>();
    static Map<String, List<Notification>> notifications = new ConcurrentHashMap<>();
    
    static int nextUserId = 3;
    static int nextPaymentId = 1;
    static int nextCertificateId = 1;
    static int nextMessageId = 1;
    static int nextReviewId = 1;
    static int nextBookingId = 1;
    static int nextSkillId = 1;
    static int nextNotifId = 1;
    
    // ==================== MODEL CLASSES ====================
    
    static class User {
        int id; String name; String email; String phone; String password; String role;
        String joinDate; String profilePic; String fingerprintEnabled; String fingerprintData;
        String headline; String bio; String address; String company; String position;
        String dateOfBirth; int age; double teachingCost; double earnings;
        List<String> skills; List<Integer> enrolledCourses; List<Integer> completedCourses;
        double latitude; double longitude;
        
        User(int id, String name, String email, String phone, String password, String role) {
            this.id = id; this.name = name; this.email = email; this.phone = phone;
            this.password = password; this.role = role; this.joinDate = new Date().toString();
            this.profilePic = ""; this.fingerprintEnabled = "false"; this.fingerprintData = "";
            this.headline = role.equals("teacher") ? "Expert Teacher" : "Aspiring Learner";
            this.bio = role.equals("teacher") ? "Passionate about teaching!" : "Eager to learn!";
            this.address = "Not set"; this.company = ""; this.position = "";
            this.dateOfBirth = ""; this.age = 0; this.teachingCost = 500; this.earnings = 0;
            this.skills = new ArrayList<>(); this.enrolledCourses = new ArrayList<>();
            this.completedCourses = new ArrayList<>(); this.latitude = 19.0760; this.longitude = 72.8777;
        }
    }
    
    static class Course {
        int id; String title; String teacher; int teacherId; String duration;
        String level; int price; int enrolled; double rating; String description;
        String category;
        
        Course(int id, String title, int teacherId, String teacher, String duration,
               String level, int price, String description, String category) {
            this.id = id; this.title = title; this.teacherId = teacherId;
            this.teacher = teacher; this.duration = duration; this.level = level;
            this.price = price; this.description = description; this.category = category;
            this.enrolled = 0; this.rating = 0;
        }
    }
    
    static class Skill {
        int id; String skillName; String description; String experienceLevel;
        String teacherEmail; String category;
        
        Skill(int id, String skillName, String description, String experienceLevel, String teacherEmail, String category) {
            this.id = id; this.skillName = skillName; this.description = description;
            this.experienceLevel = experienceLevel; this.teacherEmail = teacherEmail; this.category = category;
        }
    }
    
    static class Booking {
        int id; String learnerEmail; String teacherEmail; int courseId; String courseName;
        String bookingDate; String timeSlot; String status; int amount; String transactionId;
        
        Booking(int id, String learnerEmail, String teacherEmail, int courseId, String courseName,
                String bookingDate, String timeSlot, int amount, String transactionId) {
            this.id = id; this.learnerEmail = learnerEmail; this.teacherEmail = teacherEmail;
            this.courseId = courseId; this.courseName = courseName; this.bookingDate = bookingDate;
            this.timeSlot = timeSlot; this.status = "pending"; this.amount = amount;
            this.transactionId = transactionId;
        }
    }
    
    static class Notification {
        int id; String userEmail; String title; String message; String date; boolean read;
        
        Notification(int id, String userEmail, String title, String message) {
            this.id = id; this.userEmail = userEmail; this.title = title;
            this.message = message; this.date = new Date().toString(); this.read = false;
        }
    }
    
    static class Review {
        int id; int courseId; int userId; String userName; int rating; String comment; String date;
        
        Review(int id, int courseId, int userId, String userName, int rating, String comment) {
            this.id = id; this.courseId = courseId; this.userId = userId;
            this.userName = userName; this.rating = rating; this.comment = comment;
            this.date = new Date().toString();
        }
    }
    
    static class Payment {
        int id; String email; String phone; int courseId; String courseName; int amount;
        String transactionId; String status; String date;
        
        Payment(int id, String email, String phone, int courseId, String courseName, int amount, String transactionId) {
            this.id = id; this.email = email; this.phone = phone; this.courseId = courseId;
            this.courseName = courseName; this.amount = amount;
            this.transactionId = transactionId; this.status = "SUCCESS";
            this.date = new Date().toString();
        }
    }
    
    static class Certificate {
        int id; String email; int courseId; String courseName; String certificateId;
        String issueDate; String userName; int score; String grade;
        
        Certificate(int id, String email, int courseId, String courseName, String certificateId, String userName) {
            this.id = id; this.email = email; this.courseId = courseId;
            this.courseName = courseName; this.certificateId = certificateId;
            this.issueDate = new Date().toString(); this.userName = userName;
            this.score = 85 + new Random().nextInt(15);
            this.grade = this.score >= 90 ? "A+" : (this.score >= 80 ? "A" : (this.score >= 70 ? "B+" : "B"));
        }
    }
    
    static class ChatMessage {
        int id; String fromEmail; String toEmail; String message; String timestamp; boolean read;
        
        ChatMessage(int id, String fromEmail, String toEmail, String message) {
            this.id = id; this.fromEmail = fromEmail; this.toEmail = toEmail;
            this.message = message; this.timestamp = new Date().toString(); this.read = false;
        }
    }
    
    // ==================== INITIALIZE DEMO DATA ====================
    static {
        User defaultLearner = new User(1, "Demo Learner", "learner@skillbridge.com", "+919876543210", "learner123", "learner");
        defaultLearner.headline = "Learning Enthusiast";
        defaultLearner.bio = "I love learning new skills!";
        defaultLearner.address = "Mumbai, India";
        defaultLearner.latitude = 19.0760;
        defaultLearner.longitude = 72.8777;
        defaultLearner.skills = Arrays.asList("React", "Java", "Python");
        defaultLearner.enrolledCourses.add(1);
        users.put("learner@skillbridge.com", defaultLearner);
        
        User defaultTeacher = new User(2, "Expert Teacher", "teacher@skillbridge.com", "+919876543211", "teacher123", "teacher");
        defaultTeacher.headline = "Senior Full Stack Instructor";
        defaultTeacher.bio = "Teaching programming for 5+ years";
        defaultTeacher.address = "Andheri, Mumbai";
        defaultTeacher.latitude = 19.0780;
        defaultTeacher.longitude = 72.8800;
        defaultTeacher.skills = Arrays.asList("React", "Java", "Python", "Spring Boot");
        defaultTeacher.teachingCost = 599;
        users.put("teacher@skillbridge.com", defaultTeacher);
        
        courses.put(1, new Course(1, "React Masterclass 2024", 2, "Expert Teacher", "8 weeks", "Intermediate", 499, "Learn React from basics to advanced", "Programming"));
        courses.put(2, new Course(2, "Spring Boot Framework", 2, "Expert Teacher", "6 weeks", "Intermediate", 399, "Master Spring Boot", "Programming"));
        courses.put(3, new Course(3, "Full Stack Development", 2, "Expert Teacher", "12 weeks", "Advanced", 799, "Complete full stack course", "Programming"));
    }
    
    // ==================== HELPER METHODS ====================
    
    static void sendJson(HttpExchange exchange, int statusCode, String json) throws IOException {
        exchange.getResponseHeaders().set("Content-Type", "application/json");
        exchange.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
        exchange.getResponseHeaders().set("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
        exchange.getResponseHeaders().set("Access-Control-Allow-Headers", "Content-Type");
        exchange.sendResponseHeaders(statusCode, json.getBytes().length);
        OutputStream os = exchange.getResponseBody();
        os.write(json.getBytes());
        os.close();
    }
    
    static String readBody(HttpExchange exchange) throws IOException {
        InputStreamReader isr = new InputStreamReader(exchange.getRequestBody(), StandardCharsets.UTF_8);
        BufferedReader br = new BufferedReader(isr);
        StringBuilder body = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) body.append(line);
        return body.toString();
    }
    
    static void sendNotification(String userEmail, String title, String message) {
        Notification notif = new Notification(nextNotifId++, userEmail, title, message);
        notifications.computeIfAbsent(userEmail, k -> new ArrayList<>()).add(notif);
        System.out.println("🔔 NOTIFICATION to " + userEmail + ": " + title);
    }
    
    static void sendPaymentReceiptSMS(String phoneNumber, String courseName, String amount, String transactionId) {
        System.out.println("📱 [SMS RECEIPT] TO: " + phoneNumber);
        System.out.println("   Payment of ₹" + amount + " for " + courseName + " successful");
        System.out.println("   Transaction ID: " + transactionId);
    }
    
    static double calculateDistance(double lat1, double lon1, double lat2, double lon2) {
        double R = 6371;
        double dLat = Math.toRadians(lat2 - lat1);
        double dLon = Math.toRadians(lon2 - lon1);
        double a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                   Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
                   Math.sin(dLon/2) * Math.sin(dLon/2);
        return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    }
    
    static String arrayToJson(List<String> arr) {
        if (arr == null || arr.isEmpty()) return "[]";
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < arr.size(); i++) {
            sb.append("\"").append(arr.get(i)).append("\"");
            if (i < arr.size() - 1) sb.append(",");
        }
        sb.append("]");
        return sb.toString();
    }
    
    static int calculateAge(String dob) {
        if (dob == null || dob.isEmpty()) return 0;
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date birthDate = sdf.parse(dob);
            Date currentDate = new Date();
            long diff = currentDate.getTime() - birthDate.getTime();
            return (int) (diff / (1000L * 60 * 60 * 24 * 365));
        } catch (Exception e) { return 0; }
    }
    
    static String generateChatbotResponse(String query, String email) {
        query = query.toLowerCase();
        if (query.contains("nearby") || query.contains("location")) {
            return "📍 Enable location in your profile to find nearby users!";
        } else if (query.contains("course") || query.contains("learn")) {
            return "📚 Available courses: React (₹499), Spring Boot (₹399), Full Stack (₹799)";
        } else if (query.contains("teacher")) {
            return "👨‍🏫 Go to 'Find Teachers' tab and enter a skill to search!";
        } else if (query.contains("payment")) {
            return "💰 Click 'Enroll Now' on any course to make secure payment.";
        } else {
            return "🤖 I'm your AI assistant. Ask me about courses, teachers, or payments!";
        }
    }
    
    static String extractJsonValue(String json, String key) {
        String searchKey = "\"" + key + "\":";
        int startIndex = json.indexOf(searchKey);
        if (startIndex == -1) return null;
        startIndex += searchKey.length();
        while (startIndex < json.length() && (json.charAt(startIndex) == ' ' || json.charAt(startIndex) == '\t')) {
            startIndex++;
        }
        if (json.charAt(startIndex) == '"') {
            startIndex++;
            int endIndex = json.indexOf("\"", startIndex);
            if (endIndex == -1) return null;
            return json.substring(startIndex, endIndex);
        } else {
            int endIndex = startIndex;
            while (endIndex < json.length() && (Character.isDigit(json.charAt(endIndex)) || json.charAt(endIndex) == '.')) {
                endIndex++;
            }
            return json.substring(startIndex, endIndex);
        }
    }
    
    // ==================== MAIN SERVER ====================
    
    public static void main(String[] args) throws IOException {
        int PORT = 8888;  // Changed to 8888 to avoid conflict
        HttpServer server = HttpServer.create(new InetSocketAddress(PORT), 0);
        
        // Serve static files
        server.createContext("/", new HttpHandler() {
            public void handle(HttpExchange exchange) throws IOException {
                String path = exchange.getRequestURI().getPath();
                if (path.equals("/")) path = "/index.html";
                File file = new File("." + path);
                if (file.exists() && !file.isDirectory()) {
                    String contentType = "text/html";
                    if (path.endsWith(".css")) contentType = "text/css";
                    if (path.endsWith(".js")) contentType = "application/javascript";
                    exchange.getResponseHeaders().set("Content-Type", contentType);
                    exchange.sendResponseHeaders(200, file.length());
                    Files.copy(file.toPath(), exchange.getResponseBody());
                    exchange.getResponseBody().close();
                }
            }
        });
        
        // ==================== API: Signup ====================
        server.createContext("/api/signup", new HttpHandler() {
            public void handle(HttpExchange exchange) throws IOException {
                if ("OPTIONS".equals(exchange.getRequestMethod())) {
                    sendJson(exchange, 200, "{}");
                    return;
                }
                String body = readBody(exchange);
                try {
                    String name = body.split("\"name\":\"")[1].split("\"")[0];
                    String email = body.split("\"email\":\"")[1].split("\"")[0];
                    String phone = body.split("\"phone\":\"")[1].split("\"")[0];
                    String password = body.split("\"password\":\"")[1].split("\"")[0];
                    String role = body.contains("\"role\"") ? body.split("\"role\":\"")[1].split("\"")[0] : "learner";
                    String dob = body.contains("\"dob\"") ? body.split("\"dob\":\"")[1].split("\"")[0] : "";
                    double lat = body.contains("\"latitude\"") ? Double.parseDouble(body.split("\"latitude\":")[1].split(",")[0]) : 19.0760;
                    double lng = body.contains("\"longitude\"") ? Double.parseDouble(body.split("\"longitude\":")[1].split("}")[0]) : 72.8777;
                    
                    if (users.containsKey(email)) {
                        sendJson(exchange, 400, "{\"error\":\"User already exists\"}");
                        return;
                    }
                    
                    User newUser = new User(nextUserId++, name, email, phone, password, role);
                    newUser.dateOfBirth = dob;
                    newUser.age = calculateAge(dob);
                    newUser.latitude = lat;
                    newUser.longitude = lng;
                    users.put(email, newUser);
                    
                    sendNotification(email, "Welcome!", "Account created successfully!");
                    System.out.println("✅ New user: " + email);
                    sendJson(exchange, 200, String.format("{\"success\":true,\"user\":{\"id\":%d,\"name\":\"%s\",\"email\":\"%s\",\"phone\":\"%s\",\"role\":\"%s\"}}",
                        newUser.id, newUser.name, newUser.email, newUser.phone, newUser.role));
                } catch (Exception e) {
                    sendJson(exchange, 400, "{\"error\":\"Invalid request\"}");
                }
            }
        });
        
        // ==================== API: Login ====================
        server.createContext("/api/login", new HttpHandler() {
            public void handle(HttpExchange exchange) throws IOException {
                String body = readBody(exchange);
                try {
                    String email = body.split("\"email\":\"")[1].split("\"")[0];
                    String password = body.split("\"password\":\"")[1].split("\"")[0];
                    
                    User user = users.get(email);
                    if (user == null || !user.password.equals(password)) {
                        sendJson(exchange, 401, "{\"error\":\"Invalid credentials\"}");
                        return;
                    }
                    
                    String skillsJson = arrayToJson(user.skills);
                    sendJson(exchange, 200, String.format(
                        "{\"success\":true,\"user\":{\"id\":%d,\"name\":\"%s\",\"email\":\"%s\",\"phone\":%s,\"role\":\"%s\",\"fingerprintEnabled\":\"%s\",\"headline\":\"%s\",\"bio\":\"%s\",\"skills\":%s,\"dateOfBirth\":\"%s\",\"age\":%d,\"teachingCost\":%.2f,\"earnings\":%.2f,\"latitude\":%f,\"longitude\":%f}",
                        user.id, user.name, user.email, user.phone, user.role, user.fingerprintEnabled,
                        user.headline, user.bio, skillsJson, user.dateOfBirth, user.age, user.teachingCost, user.earnings, user.latitude, user.longitude));
                } catch (Exception e) {
                    sendJson(exchange, 400, "{\"error\":\"Invalid request\"}");
                }
            }
        });
        
        // ==================== API: Update Role ====================
        server.createContext("/api/update-role", new HttpHandler() {
            public void handle(HttpExchange exchange) throws IOException {
                String body = readBody(exchange);
                try {
                    String email = body.split("\"email\":\"")[1].split("\"")[0];
                    String role = body.split("\"role\":\"")[1].split("\"")[0];
                    User user = users.get(email);
                    if (user != null) {
                        user.role = role;
                        sendJson(exchange, 200, "{\"success\":true}");
                    }
                } catch (Exception e) {
                    sendJson(exchange, 400, "{\"error\":\"Invalid request\"}");
                }
            }
        });
        
        // ==================== API: Get User ====================
        server.createContext("/api/user", new HttpHandler() {
            public void handle(HttpExchange exchange) throws IOException {
                String query = exchange.getRequestURI().getQuery();
                String email = query.split("email=")[1];
                User user = users.get(email);
                if (user != null) {
                    String skillsJson = arrayToJson(user.skills);
                    sendJson(exchange, 200, String.format(
                        "{\"id\":%d,\"name\":\"%s\",\"email\":\"%s\",\"phone\":\"%s\",\"role\":\"%s\",\"profilePic\":\"%s\",\"address\":\"%s\",\"fingerprintEnabled\":\"%s\",\"headline\":\"%s\",\"bio\":\"%s\",\"company\":\"%s\",\"position\":\"%s\",\"skills\":%s,\"latitude\":%f,\"longitude\":%f,\"dateOfBirth\":\"%s\",\"age\":%d,\"teachingCost\":%.2f,\"earnings\":%.2f}",
                        user.id, user.name, user.email, user.phone, user.role, user.profilePic, user.address, user.fingerprintEnabled,
                        user.headline, user.bio, user.company, user.position, skillsJson, user.latitude, user.longitude, user.dateOfBirth, user.age, user.teachingCost, user.earnings));
                } else {
                    sendJson(exchange, 404, "{\"error\":\"User not found\"}");
                }
            }
        });
        
        // ==================== API: Update Profile ====================
        server.createContext("/api/user/update", new HttpHandler() {
            public void handle(HttpExchange exchange) throws IOException {
                String body = readBody(exchange);
                try {
                    String email = body.split("\"email\":\"")[1].split("\"")[0];
                    String name = body.split("\"name\":\"")[1].split("\"")[0];
                    String headline = body.split("\"headline\":\"")[1].split("\"")[0];
                    String bio = body.split("\"bio\":\"")[1].split("\"")[0];
                    String address = body.contains("\"address\"") ? body.split("\"address\":\"")[1].split("\"")[0] : "";
                    String company = body.contains("\"company\"") ? body.split("\"company\":\"")[1].split("\"")[0] : "";
                    String position = body.contains("\"position\"") ? body.split("\"position\":\"")[1].split("\"")[0] : "";
                    String dob = body.contains("\"dateOfBirth\"") ? body.split("\"dateOfBirth\":\"")[1].split("\"")[0] : "";
                    double lat = body.contains("\"latitude\"") ? Double.parseDouble(body.split("\"latitude\":")[1].split(",")[0]) : 0;
                    double lng = body.contains("\"longitude\"") ? Double.parseDouble(body.split("\"longitude\":")[1].split("}")[0]) : 0;
                    
                    User user = users.get(email);
                    if (user != null) {
                        user.name = name; user.headline = headline; user.bio = bio;
                        user.address = address; user.company = company; user.position = position;
                        if (!dob.isEmpty()) { user.dateOfBirth = dob; user.age = calculateAge(dob); }
                        if (lat != 0) { user.latitude = lat; user.longitude = lng; }
                        sendJson(exchange, 200, "{\"success\":true}");
                    }
                } catch (Exception e) {
                    sendJson(exchange, 400, "{\"error\":\"Invalid request\"}");
                }
            }
        });
        
        // ==================== API: Update Skills ====================
        server.createContext("/api/user/skills", new HttpHandler() {
            public void handle(HttpExchange exchange) throws IOException {
                String body = readBody(exchange);
                try {
                    String email = body.split("\"email\":\"")[1].split("\"")[0];
                    String skillsStr = body.split("\"skills\":\"")[1].split("\"")[0];
                    User user = users.get(email);
                    if (user != null) {
                        user.skills = Arrays.asList(skillsStr.split(","));
                        sendJson(exchange, 200, "{\"success\":true}");
                    }
                } catch (Exception e) {
                    sendJson(exchange, 400, "{\"error\":\"Invalid request\"}");
                }
            }
        });
        
        // ==================== API: Add Skill ====================
        server.createContext("/api/add-skill", new HttpHandler() {
            public void handle(HttpExchange exchange) throws IOException {
                String body = readBody(exchange);
                try {
                    String email = body.split("\"email\":\"")[1].split("\"")[0];
                    String skillName = body.split("\"skillName\":\"")[1].split("\"")[0];
                    String description = body.split("\"description\":\"")[1].split("\"")[0];
                    String experienceLevel = body.split("\"experienceLevel\":\"")[1].split("\"")[0];
                    String category = body.split("\"category\":\"")[1].split("\"")[0];
                    
                    User user = users.get(email);
                    if (user != null && user.role.equals("teacher")) {
                        Skill skill = new Skill(nextSkillId++, skillName, description, experienceLevel, email, category);
                        skills.computeIfAbsent(email, k -> new ArrayList<>()).add(skill);
                        user.skills.add(skillName);
                        sendJson(exchange, 200, "{\"success\":true}");
                    }
                } catch (Exception e) {
                    sendJson(exchange, 400, "{\"error\":\"Invalid request\"}");
                }
            }
        });
        
        // ==================== API: Get Skills ====================
        server.createContext("/api/get-skills", new HttpHandler() {
            public void handle(HttpExchange exchange) throws IOException {
                String query = exchange.getRequestURI().getQuery();
                String email = query.split("email=")[1];
                List<Skill> userSkills = skills.getOrDefault(email, new ArrayList<>());
                StringBuilder json = new StringBuilder("[");
                boolean first = true;
                for (Skill s : userSkills) {
                    if (!first) json.append(",");
                    json.append(String.format("{\"id\":%d,\"skillName\":\"%s\",\"description\":\"%s\",\"experienceLevel\":\"%s\",\"category\":\"%s\"}",
                        s.id, s.skillName, s.description, s.experienceLevel, s.category));
                    first = false;
                }
                json.append("]");
                sendJson(exchange, 200, json.toString());
            }
        });
        
        // ==================== API: Update Teaching Cost ====================
        server.createContext("/api/update-teaching-cost", new HttpHandler() {
            public void handle(HttpExchange exchange) throws IOException {
                String body = readBody(exchange);
                try {
                    String email = body.split("\"email\":\"")[1].split("\"")[0];
                    double cost = Double.parseDouble(body.split("\"cost\":")[1].split("}")[0]);
                    User user = users.get(email);
                    if (user != null && user.role.equals("teacher")) {
                        user.teachingCost = cost;
                        sendJson(exchange, 200, "{\"success\":true}");
                    }
                } catch (Exception e) {
                    sendJson(exchange, 400, "{\"error\":\"Invalid request\"}");
                }
            }
        });
        
        // ==================== API: Search Teachers ====================
        server.createContext("/api/search-teachers", new HttpHandler() {
            public void handle(HttpExchange exchange) throws IOException {
                String query = exchange.getRequestURI().getQuery();
                String skill = query.split("skill=")[1].split("&")[0];
                String learnerEmail = query.split("learnerEmail=")[1];
                double radius = query.contains("radius=") ? Double.parseDouble(query.split("radius=")[1]) : 10.0;
                
                User learner = users.get(learnerEmail);
                List<Map<String, Object>> results = new ArrayList<>();
                for (User u : users.values()) {
                    if (u.role.equals("teacher") && u.skills.contains(skill)) {
                        double distance = calculateDistance(learner.latitude, learner.longitude, u.latitude, u.longitude);
                        if (distance <= radius) {
                            Map<String, Object> result = new HashMap<>();
                            result.put("name", u.name);
                            result.put("email", u.email);
                            result.put("headline", u.headline);
                            result.put("distance", Math.round(distance * 10) / 10.0);
                            result.put("teachingCost", u.teachingCost);
                            result.put("rating", 4.8);
                            results.add(result);
                        }
                    }
                }
                StringBuilder json = new StringBuilder("[");
                boolean first = true;
                for (Map<String, Object> r : results) {
                    if (!first) json.append(",");
                    json.append(String.format("{\"name\":\"%s\",\"email\":\"%s\",\"headline\":\"%s\",\"distance\":%.1f,\"teachingCost\":%.2f,\"rating\":%.1f}",
                        r.get("name"), r.get("email"), r.get("headline"), r.get("distance"), r.get("teachingCost"), r.get("rating")));
                    first = false;
                }
                json.append("]");
                sendJson(exchange, 200, json.toString());
            }
        });
        
        // ==================== API: Update Location ====================
        server.createContext("/api/update-location", new HttpHandler() {
            public void handle(HttpExchange exchange) throws IOException {
                String body = readBody(exchange);
                try {
                    String email = body.split("\"email\":\"")[1].split("\"")[0];
                    double lat = Double.parseDouble(body.split("\"latitude\":")[1].split(",")[0]);
                    double lng = Double.parseDouble(body.split("\"longitude\":")[1].split("}")[0]);
                    User user = users.get(email);
                    if (user != null) {
                        user.latitude = lat;
                        user.longitude = lng;
                        sendJson(exchange, 200, "{\"success\":true}");
                    }
                } catch (Exception e) {
                    sendJson(exchange, 400, "{\"error\":\"Invalid request\"}");
                }
            }
        });
        
        // ==================== API: Get Nearby Users ====================
        server.createContext("/api/nearby", new HttpHandler() {
            public void handle(HttpExchange exchange) throws IOException {
                String query = exchange.getRequestURI().getQuery();
                String email = query.split("email=")[1];
                User currentUser = users.get(email);
                List<Map<String, Object>> nearby = new ArrayList<>();
                for (User u : users.values()) {
                    if (!u.email.equals(email)) {
                        double distance = calculateDistance(currentUser.latitude, currentUser.longitude, u.latitude, u.longitude);
                        if (distance <= 10) {
                            Map<String, Object> info = new HashMap<>();
                            info.put("name", u.name); info.put("email", u.email); info.put("role", u.role);
                            info.put("headline", u.headline); info.put("distance", Math.round(distance * 10) / 10.0);
                            nearby.add(info);
                        }
                    }
                }
                nearby.sort((a, b) -> Double.compare((double)a.get("distance"), (double)b.get("distance")));
                StringBuilder json = new StringBuilder("[");
                boolean first = true;
                for (Map<String, Object> n : nearby) {
                    if (!first) json.append(",");
                    json.append(String.format("{\"name\":\"%s\",\"email\":\"%s\",\"role\":\"%s\",\"headline\":\"%s\",\"distance\":%.1f}",
                        n.get("name"), n.get("email"), n.get("role"), n.get("headline"), n.get("distance")));
                    first = false;
                }
                json.append("]");
                sendJson(exchange, 200, json.toString());
            }
        });
        
        // ==================== API: Create Booking ====================
        server.createContext("/api/create-booking", new HttpHandler() {
            public void handle(HttpExchange exchange) throws IOException {
                String body = readBody(exchange);
                try {
                    String learnerEmail = body.split("\"learnerEmail\":\"")[1].split("\"")[0];
                    String teacherEmail = body.split("\"teacherEmail\":\"")[1].split("\"")[0];
                    int courseId = Integer.parseInt(body.split("\"courseId\":")[1].split(",")[0]);
                    String bookingDate = body.split("\"bookingDate\":\"")[1].split("\"")[0];
                    String timeSlot = body.split("\"timeSlot\":\"")[1].split("\"")[0];
                    int amount = Integer.parseInt(body.split("\"amount\":")[1].split(",")[0]);
                    String transactionId = body.split("\"transactionId\":\"")[1].split("\"")[0];
                    
                    Course course = courses.get(courseId);
                    Booking booking = new Booking(nextBookingId++, learnerEmail, teacherEmail, courseId, course.title, bookingDate, timeSlot, amount, transactionId);
                    bookings.computeIfAbsent(learnerEmail, k -> new ArrayList<>()).add(booking);
                    bookings.computeIfAbsent(teacherEmail, k -> new ArrayList<>()).add(booking);
                    
                    sendNotification(learnerEmail, "Booking Confirmed", "Session on " + bookingDate + " at " + timeSlot);
                    sendNotification(teacherEmail, "New Booking", "New booking for " + course.title);
                    sendJson(exchange, 200, "{\"success\":true,\"bookingId\":" + booking.id + "}");
                } catch (Exception e) {
                    sendJson(exchange, 400, "{\"error\":\"Invalid request\"}");
                }
            }
        });
        
        // ==================== API: Get Bookings ====================
        server.createContext("/api/get-bookings", new HttpHandler() {
            public void handle(HttpExchange exchange) throws IOException {
                String query = exchange.getRequestURI().getQuery();
                String email = query.split("email=")[1];
                List<Booking> userBookings = bookings.getOrDefault(email, new ArrayList<>());
                StringBuilder json = new StringBuilder("[");
                boolean first = true;
                for (Booking b : userBookings) {
                    if (!first) json.append(",");
                    json.append(String.format("{\"id\":%d,\"courseName\":\"%s\",\"bookingDate\":\"%s\",\"timeSlot\":\"%s\",\"status\":\"%s\",\"amount\":%d,\"transactionId\":\"%s\"}",
                        b.id, b.courseName, b.bookingDate, b.timeSlot, b.status, b.amount, b.transactionId));
                    first = false;
                }
                json.append("]");
                sendJson(exchange, 200, json.toString());
            }
        });
        
        // ==================== API: Process Payment ====================
        server.createContext("/api/process-payment", new HttpHandler() {
            public void handle(HttpExchange exchange) throws IOException {
                if ("OPTIONS".equals(exchange.getRequestMethod())) {
                    sendJson(exchange, 200, "{}");
                    return;
                }
                String body = readBody(exchange);
                try {
                    String email = extractJsonValue(body, "email");
                    String courseIdStr = extractJsonValue(body, "courseId");
                    String amountStr = extractJsonValue(body, "amount");
                    
                    if (email == null || courseIdStr == null || amountStr == null) {
                        sendJson(exchange, 400, "{\"error\":\"Missing fields\"}");
                        return;
                    }
                    
                    int courseId = Integer.parseInt(courseIdStr);
                    int amount = Integer.parseInt(amountStr);
                    
                    User user = users.get(email);
                    Course course = courses.get(courseId);
                    if (user == null || course == null) {
                        sendJson(exchange, 404, "{\"error\":\"Not found\"}");
                        return;
                    }
                    
                    String transactionId = "TXN" + System.currentTimeMillis() + UUID.randomUUID().toString().substring(0, 6).toUpperCase();
                    Payment payment = new Payment(nextPaymentId++, email, user.phone, courseId, course.title, amount, transactionId);
                    payments.computeIfAbsent(email, k -> new ArrayList<>()).add(payment);
                    
                    if (!user.enrolledCourses.contains(courseId)) {
                        user.enrolledCourses.add(courseId);
                    }
                    
                    sendPaymentReceiptSMS(user.phone, course.title, String.valueOf(amount), transactionId);
                    sendNotification(email, "Payment Successful", "Paid ₹" + amount + " for " + course.title);
                    sendJson(exchange, 200, String.format("{\"success\":true,\"transactionId\":\"%s\",\"amount\":%d,\"courseName\":\"%s\"}", 
                        transactionId, amount, course.title));
                } catch (Exception e) {
                    sendJson(exchange, 400, "{\"error\":\"Invalid request\"}");
                }
            }
        });
        
        // ==================== API: Get Payments ====================
        server.createContext("/api/get-payments", new HttpHandler() {
            public void handle(HttpExchange exchange) throws IOException {
                String query = exchange.getRequestURI().getQuery();
                String email = query.split("email=")[1];
                List<Payment> userPayments = payments.getOrDefault(email, new ArrayList<>());
                StringBuilder json = new StringBuilder("[");
                boolean first = true;
                for (Payment p : userPayments) {
                    if (!first) json.append(",");
                    json.append(String.format("{\"courseName\":\"%s\",\"amount\":%d,\"transactionId\":\"%s\",\"date\":\"%s\"}",
                        p.courseName, p.amount, p.transactionId, p.date));
                    first = false;
                }
                json.append("]");
                sendJson(exchange, 200, json.toString());
            }
        });
        
        // ==================== API: Dashboard ====================
        server.createContext("/api/dashboard", new HttpHandler() {
            public void handle(HttpExchange exchange) throws IOException {
                String query = exchange.getRequestURI().getQuery();
                String email = query.split("email=")[1];
                User user = users.get(email);
                if (user == null) {
                    sendJson(exchange, 404, "{\"error\":\"User not found\"}");
                    return;
                }
                List<Booking> userBookings = bookings.getOrDefault(email, new ArrayList<>());
                List<Payment> userPayments = payments.getOrDefault(email, new ArrayList<>());
                double totalSpent = 0;
                for (Payment p : userPayments) totalSpent += p.amount;
                sendJson(exchange, 200, String.format(
                    "{\"enrolledCourses\":%d,\"completedCourses\":%d,\"totalSpent\":%.2f,\"activeBookings\":%d,\"earnings\":%.2f,\"teachingCost\":%.2f}",
                    user.enrolledCourses.size(), user.completedCourses.size(), totalSpent,
                    userBookings.stream().filter(b -> b.status.equals("pending")).count(),
                    user.earnings, user.teachingCost));
            }
        });
        
        // ==================== API: Get Notifications ====================
        server.createContext("/api/get-notifications", new HttpHandler() {
            public void handle(HttpExchange exchange) throws IOException {
                String query = exchange.getRequestURI().getQuery();
                String email = query.split("email=")[1];
                List<Notification> userNotifs = notifications.getOrDefault(email, new ArrayList<>());
                StringBuilder json = new StringBuilder("[");
                boolean first = true;
                for (Notification n : userNotifs) {
                    if (!first) json.append(",");
                    json.append(String.format("{\"id\":%d,\"title\":\"%s\",\"message\":\"%s\",\"date\":\"%s\",\"read\":%b}",
                        n.id, n.title, n.message, n.date, n.read));
                    first = false;
                }
                json.append("]");
                sendJson(exchange, 200, json.toString());
            }
        });
        
        // ==================== API: Get Courses ====================
        server.createContext("/api/courses", new HttpHandler() {
            public void handle(HttpExchange exchange) throws IOException {
                StringBuilder json = new StringBuilder("[");
                boolean first = true;
                for (Course c : courses.values()) {
                    if (!first) json.append(",");
                    json.append(String.format("{\"id\":%d,\"title\":\"%s\",\"teacher\":\"%s\",\"duration\":\"%s\",\"level\":\"%s\",\"price\":%d,\"rating\":%.1f,\"description\":\"%s\"}",
                        c.id, c.title, c.teacher, c.duration, c.level, c.price, c.rating, c.description));
                    first = false;
                }
                json.append("]");
                sendJson(exchange, 200, json.toString());
            }
        });
        
        // ==================== API: Get User Courses ====================
        server.createContext("/api/user-courses", new HttpHandler() {
            public void handle(HttpExchange exchange) throws IOException {
                String query = exchange.getRequestURI().getQuery();
                String email = query.split("email=")[1];
                User user = users.get(email);
                StringBuilder json = new StringBuilder("[");
                boolean first = true;
                for (int courseId : user.enrolledCourses) {
                    Course c = courses.get(courseId);
                    if (c != null) {
                        if (!first) json.append(",");
                        boolean completed = user.completedCourses.contains(courseId);
                        json.append(String.format("{\"id\":%d,\"title\":\"%s\",\"completed\":%b,\"progress\":%d,\"teacher\":\"%s\"}",
                            c.id, c.title, completed, completed ? 100 : 50, c.teacher));
                        first = false;
                    }
                }
                json.append("]");
                sendJson(exchange, 200, json.toString());
            }
        });
        
        // ==================== API: Complete Course ====================
        server.createContext("/api/complete-course", new HttpHandler() {
            public void handle(HttpExchange exchange) throws IOException {
                String query = exchange.getRequestURI().getQuery();
                try {
                    String email = query.split("email=")[1].split("&")[0];
                    int courseId = Integer.parseInt(query.split("courseId=")[1]);
                    int rating = query.contains("rating=") ? Integer.parseInt(query.split("rating=")[1]) : 0;
                    String review = query.contains("review=") ? URLDecoder.decode(query.split("review=")[1], "UTF-8") : "";
                    
                    User user = users.get(email);
                    Course course = courses.get(courseId);
                    
                    if (!user.completedCourses.contains(courseId)) {
                        user.completedCourses.add(courseId);
                        String certificateId = "SBC" + System.currentTimeMillis() + user.id;
                        Certificate cert = new Certificate(nextCertificateId++, email, courseId, course.title, certificateId, user.name);
                        certificates.computeIfAbsent(email, k -> new ArrayList<>()).add(cert);
                        
                        if (rating > 0) {
                            Review newReview = new Review(nextReviewId++, courseId, user.id, user.name, rating, review);
                            reviews.computeIfAbsent(courseId, k -> new ArrayList<>()).add(newReview);
                            double avg = 0;
                            for (Review r : reviews.get(courseId)) avg += r.rating;
                            avg = avg / reviews.get(courseId).size();
                            course.rating = Math.round(avg * 10) / 10.0;
                        }
                        
                        sendNotification(email, "Course Completed!", "You completed " + course.title + "!");
                        sendJson(exchange, 200, String.format("{\"success\":true,\"message\":\"Course completed! Certificate issued\",\"certificateId\":\"%s\"}", certificateId));
                    } else {
                        sendJson(exchange, 200, "{\"success\":true,\"message\":\"Already completed\"}");
                    }
                } catch (Exception e) {
                    sendJson(exchange, 400, "{\"error\":\"Invalid request\"}");
                }
            }
        });
        
        // ==================== API: Get Certificates ====================
        server.createContext("/api/get-certificates", new HttpHandler() {
            public void handle(HttpExchange exchange) throws IOException {
                String query = exchange.getRequestURI().getQuery();
                String email = query.split("email=")[1];
                List<Certificate> userCerts = certificates.getOrDefault(email, new ArrayList<>());
                StringBuilder json = new StringBuilder("[");
                boolean first = true;
                for (Certificate c : userCerts) {
                    if (!first) json.append(",");
                    json.append(String.format("{\"id\":%d,\"courseName\":\"%s\",\"certificateId\":\"%s\",\"issueDate\":\"%s\",\"score\":%d,\"grade\":\"%s\"}",
                        c.id, c.courseName, c.certificateId, c.issueDate, c.score, c.grade));
                    first = false;
                }
                json.append("]");
                sendJson(exchange, 200, json.toString());
            }
        });
        
        // ==================== API: Download Certificate ====================
        server.createContext("/api/download-certificate", new HttpHandler() {
            public void handle(HttpExchange exchange) throws IOException {
                String query = exchange.getRequestURI().getQuery();
                String email = query.split("email=")[1];
                int courseId = Integer.parseInt(query.split("courseId=")[1]);
                
                List<Certificate> userCerts = certificates.getOrDefault(email, new ArrayList<>());
                Certificate found = null;
                for (Certificate c : userCerts) {
                    if (c.courseId == courseId) {
                        found = c;
                        break;
                    }
                }
                
                if (found != null) {
                    String html = "<!DOCTYPE html><html><head><title>Certificate</title><style>" +
                        "body{font-family:Arial;text-align:center;padding:50px}" +
                        ".cert{border:10px solid gold;background:white;padding:40px;max-width:800px;margin:0 auto}" +
                        "button{background:#667eea;color:white;border:none;padding:10px 20px;border-radius:10px;cursor:pointer}" +
                        "</style></head><body>" +
                        "<div class='cert'><h1>CERTIFICATE OF COMPLETION</h1>" +
                        "<p>Presented to</p><h2>" + found.userName + "</h2>" +
                        "<p>for completing</p><h3>" + found.courseName + "</h3>" +
                        "<p>Score: " + found.score + "% | Grade: " + found.grade + "</p>" +
                        "<p>Certificate ID: " + found.certificateId + "</p>" +
                        "<p>Issue Date: " + found.issueDate + "</p>" +
                        "<button onclick='window.print()'>Print Certificate</button>" +
                        "</div></body></html>";
                    exchange.getResponseHeaders().set("Content-Type", "text/html");
                    exchange.sendResponseHeaders(200, html.getBytes().length);
                    exchange.getResponseBody().write(html.getBytes());
                    exchange.getResponseBody().close();
                } else {
                    sendJson(exchange, 404, "{\"error\":\"Certificate not found\"}");
                }
            }
        });
        
        // ==================== API: Chatbot ====================
        server.createContext("/api/chatbot", new HttpHandler() {
            public void handle(HttpExchange exchange) throws IOException {
                String body = readBody(exchange);
                try {
                    String query = body.split("\"query\":\"")[1].split("\"")[0];
                    String email = body.split("\"email\":\"")[1].split("\"")[0];
                    String response = generateChatbotResponse(query, email);
                    sendJson(exchange, 200, String.format("{\"response\":\"%s\"}", response.replace("\"", "\\\"")));
                } catch (Exception e) {
                    sendJson(exchange, 400, "{\"error\":\"Invalid request\"}");
                }
            }
        });
        
        // ==================== API: Send Message ====================
        server.createContext("/api/send-message", new HttpHandler() {
            public void handle(HttpExchange exchange) throws IOException {
                String body = readBody(exchange);
                try {
                    String fromEmail = body.split("\"fromEmail\":\"")[1].split("\"")[0];
                    String toEmail = body.split("\"toEmail\":\"")[1].split("\"")[0];
                    String message = body.split("\"message\":\"")[1].split("\"")[0];
                    
                    ChatMessage chat = new ChatMessage(nextMessageId++, fromEmail, toEmail, message);
                    chats.computeIfAbsent(fromEmail, k -> new ArrayList<>()).add(chat);
                    chats.computeIfAbsent(toEmail, k -> new ArrayList<>()).add(chat);
                    sendNotification(toEmail, "New Message", "Message from " + fromEmail);
                    sendJson(exchange, 200, "{\"success\":true}");
                } catch (Exception e) {
                    sendJson(exchange, 400, "{\"error\":\"Invalid request\"}");
                }
            }
        });
        
        // ==================== API: Get Messages ====================
        server.createContext("/api/get-messages", new HttpHandler() {
            public void handle(HttpExchange exchange) throws IOException {
                String query = exchange.getRequestURI().getQuery();
                String email = query.split("email=")[1];
                List<ChatMessage> userMessages = chats.getOrDefault(email, new ArrayList<>());
                StringBuilder json = new StringBuilder("[");
                boolean first = true;
                for (ChatMessage m : userMessages) {
                    if (!first) json.append(",");
                    json.append(String.format("{\"fromEmail\":\"%s\",\"toEmail\":\"%s\",\"message\":\"%s\",\"timestamp\":\"%s\"}",
                        m.fromEmail, m.toEmail, m.message, m.timestamp));
                    first = false;
                }
                json.append("]");
                sendJson(exchange, 200, json.toString());
            }
        });
        
        // ==================== API: Enable Fingerprint ====================
        server.createContext("/api/enable-fingerprint", new HttpHandler() {
            public void handle(HttpExchange exchange) throws IOException {
                String body = readBody(exchange);
                try {
                    String email = body.split("\"email\":\"")[1].split("\"")[0];
                    String fingerprintData = body.split("\"fingerprintData\":\"")[1].split("\"")[0];
                    User user = users.get(email);
                    if (user != null) {
                        user.fingerprintEnabled = "true";
                        user.fingerprintData = fingerprintData;
                        sendJson(exchange, 200, "{\"success\":true}");
                    }
                } catch (Exception e) {
                    sendJson(exchange, 400, "{\"error\":\"Invalid request\"}");
                }
            }
        });
        
        // ==================== API: Disable Fingerprint ====================
        server.createContext("/api/disable-fingerprint", new HttpHandler() {
            public void handle(HttpExchange exchange) throws IOException {
                String body = readBody(exchange);
                try {
                    String email = body.split("\"email\":\"")[1].split("\"")[0];
                    User user = users.get(email);
                    if (user != null) {
                        user.fingerprintEnabled = "false";
                        user.fingerprintData = "";
                        sendJson(exchange, 200, "{\"success\":true}");
                    }
                } catch (Exception e) {
                    sendJson(exchange, 400, "{\"error\":\"Invalid request\"}");
                }
            }
        });
        
        // ==================== API: Login with Fingerprint ====================
        server.createContext("/api/login-fingerprint", new HttpHandler() {
            public void handle(HttpExchange exchange) throws IOException {
                String body = readBody(exchange);
                try {
                    String email = body.split("\"email\":\"")[1].split("\"")[0];
                    String fingerprintData = body.split("\"fingerprintData\":\"")[1].split("\"")[0];
                    User user = users.get(email);
                    if (user != null && "true".equals(user.fingerprintEnabled) && user.fingerprintData.equals(fingerprintData)) {
                        String skillsJson = arrayToJson(user.skills);
                        sendJson(exchange, 200, String.format(
                            "{\"success\":true,\"user\":{\"id\":%d,\"name\":\"%s\",\"email\":\"%s\",\"phone\":\"%s\",\"role\":\"%s\",\"fingerprintEnabled\":\"%s\",\"headline\":\"%s\",\"bio\":\"%s\",\"skills\":%s}}",
                            user.id, user.name, user.email, user.phone, user.role, user.fingerprintEnabled,
                            user.headline, user.bio, skillsJson));
                    } else {
                        sendJson(exchange, 401, "{\"error\":\"Fingerprint verification failed\"}");
                    }
                } catch (Exception e) {
                    sendJson(exchange, 400, "{\"error\":\"Invalid request\"}");
                }
            }
        });
        
        // ==================== API: Change Password ====================
        server.createContext("/api/change-password", new HttpHandler() {
            public void handle(HttpExchange exchange) throws IOException {
                String body = readBody(exchange);
                try {
                    String email = body.split("\"email\":\"")[1].split("\"")[0];
                    String oldPassword = body.split("\"oldPassword\":\"")[1].split("\"")[0];
                    String newPassword = body.split("\"newPassword\":\"")[1].split("\"")[0];
                    
                    User user = users.get(email);
                    if (user != null && user.password.equals(oldPassword)) {
                        user.password = newPassword;
                        sendJson(exchange, 200, "{\"success\":true}");
                    } else {
                        sendJson(exchange, 401, "{\"error\":\"Invalid old password\"}");
                    }
                } catch (Exception e) {
                    sendJson(exchange, 400, "{\"error\":\"Invalid request\"}");
                }
            }
        });
        
        System.out.println("\n=========================================");
        System.out.println("   SKILLBRIDGE CONNECT SERVER RUNNING");
        System.out.println("   =========================================");
        System.out.println("   🚀 Server: http://localhost:" + PORT);
        System.out.println("   📝 Default Users:");
        System.out.println("      Learner: learner@skillbridge.com / learner123");
        System.out.println("      Teacher: teacher@skillbridge.com / teacher123");
        System.out.println("   🔐 Fingerprint authentication available");
        System.out.println("   =========================================\n");
        
        server.start();
    }
}