package com.skillbridge.controller;

import com.skillbridge.model.User;
import com.skillbridge.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.util.*;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class UserController {
    
    @Autowired
    private UserService userService;
    
    @GetMapping("/user/{id}")
    public ResponseEntity<?> getUser(@PathVariable int id) {
        User user = userService.getUserById(id);
        if (user == null) return ResponseEntity.notFound().build();
        user.setPassword(null);
        return ResponseEntity.ok(user);
    }
    
    @PutMapping("/user/{id}")
    public ResponseEntity<?> updateUser(@PathVariable int id, @RequestBody Map<String, Object> updates) {
        User user = userService.updateUser(id, updates);
        if (user == null) return ResponseEntity.notFound().build();
        user.setPassword(null);
        return ResponseEntity.ok(user);
    }
    
    @PostMapping("/upload-profile/{userId}")
    public ResponseEntity<?> uploadProfilePic(@PathVariable int userId, @RequestParam("profilePic") MultipartFile file) {
        try {
            String uploadDir = "uploads/";
            new File(uploadDir).mkdirs();
            String filename = "profile_" + userId + "_" + UUID.randomUUID().toString() + ".jpg";
            File destFile = new File(uploadDir + filename);
            file.transferTo(destFile);
            String profilePicPath = "/uploads/" + filename;
            User user = userService.updateProfilePic(userId, profilePicPath);
            return ResponseEntity.ok(Map.of("success", true, "profilePic", profilePicPath));
        } catch (Exception e) {
            return ResponseEntity.status(500).body(Map.of("error", e.getMessage()));
        }
    }
    
    @GetMapping("/nearby/{userId}")
    public ResponseEntity<?> getNearbyUsers(@PathVariable int userId, @RequestParam(defaultValue = "5") int radius) {
        List<User> nearby = userService.getNearbyUsers(userId, radius);
        nearby.forEach(u -> u.setPassword(null));
        return ResponseEntity.ok(nearby);
    }
    
    @GetMapping("/teachers")
    public ResponseEntity<?> getTeachers() {
        List<User> teachers = userService.getTeachers();
        teachers.forEach(t -> t.setPassword(null));
        return ResponseEntity.ok(teachers);
    }
}