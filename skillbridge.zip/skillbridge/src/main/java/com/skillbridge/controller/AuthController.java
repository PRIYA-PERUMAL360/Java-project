package com.skillbridge.controller;

import com.skillbridge.model.User;
import com.skillbridge.service.UserService;
import com.skillbridge.utils.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class AuthController {
    
    @Autowired
    private UserService userService;
    
    @Autowired
    private JwtUtil jwtUtil;
    
    @PostMapping("/signup")
    public ResponseEntity<?> signup(@RequestBody Map<String, String> request) {
        try {
            String name = request.get("name");
            String email = request.get("email");
            String phone = request.get("phone");
            String password = request.get("password");
            String role = request.getOrDefault("role", "learner");
            
            User user = userService.signup(name, email, phone, password, role);
            String token = jwtUtil.generateToken(user.getId(), user.getEmail());
            
            Map<String, Object> response = new HashMap<>();
            response.put("token", token);
            user.setPassword(null);
            response.put("user", user);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }
    
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> request) {
        try {
            String email = request.get("email");
            String password = request.get("password");
            
            User user = userService.login(email, password);
            String token = jwtUtil.generateToken(user.getId(), user.getEmail());
            
            Map<String, Object> response = new HashMap<>();
            response.put("token", token);
            user.setPassword(null);
            response.put("user", user);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.status(401).body(Map.of("error", e.getMessage()));
        }
    }
}