package com.skillbridge.controller;

import com.skillbridge.model.Course;
import com.skillbridge.model.ScheduledClass;
import com.skillbridge.model.User;
import com.skillbridge.service.CourseService;
import com.skillbridge.service.NotificationService;
import com.skillbridge.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class CourseController {
    
    @Autowired
    private CourseService courseService;
    
    @Autowired
    private UserService userService;
    
    @Autowired
    private NotificationService notificationService;
    
    @GetMapping("/courses")
    public ResponseEntity<List<Course>> getCourses() {
        return ResponseEntity.ok(courseService.getAllCourses());
    }
    
    @PostMapping("/enroll/{userId}/{courseId}")
    public ResponseEntity<?> enrollCourse(@PathVariable int userId, @PathVariable int courseId) {
        try {
            courseService.enrollCourse(userId, courseId);
            return ResponseEntity.ok(Map.of("success", true));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }
    
    @PostMapping("/schedule-class")
    public ResponseEntity<?> scheduleClass(@RequestBody Map<String, Object> request) {
        try {
            int userId = (int) request.get("userId");
            int courseId = (int) request.get("courseId");
            String scheduledDateTime = (String) request.get("scheduledDateTime");
            String timezone = (String) request.getOrDefault("timezone", "IST");
            
            ScheduledClass scheduledClass = courseService.scheduleClass(userId, courseId, scheduledDateTime, timezone);
            return ResponseEntity.ok(Map.of("success", true, "scheduledClass", scheduledClass));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }
    
    @GetMapping("/my-classes/{userId}")
    public ResponseEntity<List<ScheduledClass>> getMyClasses(@PathVariable int userId) {
        return ResponseEntity.ok(courseService.getUserClasses(userId));
    }
    
    @PostMapping("/tab-violation")
    public ResponseEntity<?> reportTabViolation(@RequestBody Map<String, Integer> request) {
        int userId = request.get("userId");
        int courseId = request.get("courseId");
        Map<String, Object> result = courseService.handleTabViolation(userId, courseId);
        return ResponseEntity.ok(result);
    }
    
    @GetMapping("/tab-status/{userId}")
    public ResponseEntity<?> getTabStatus(@PathVariable int userId) {
        User user = userService.getUserById(userId);
        int switches = user != null ? user.getTabSwitches() : 0;
        return ResponseEntity.ok(Map.of(
            "tabSwitches", switches,
            "remaining", Math.max(0, 5 - switches),
            "isBlocked", user != null && user.isBlocked()
        ));
    }
    
    @PostMapping("/complete-course/{userId}/{courseId}")
    public ResponseEntity<?> completeCourse(@PathVariable int userId, @PathVariable int courseId, 
                                            @RequestBody Map<String, Object> request) {
        try {
            Integer rating = request.containsKey("rating") ? (Integer) request.get("rating") : null;
            String review = (String) request.getOrDefault("review", "");
            Map<String, Object> result = courseService.completeCourse(userId, courseId, rating, review);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }
    
    @PostMapping("/process-payment")
    public ResponseEntity<?> processPayment(@RequestBody Map<String, Object> request) {
        int userId = (int) request.get("userId");
        int courseId = (int) request.get("courseId");
        int amount = (int) request.get("amount");
        
        String transactionId = "TXN-" + System.currentTimeMillis() + "-" + UUID.randomUUID().toString().substring(0, 6);
        
        User user = userService.getUserById(userId);
        Course course = courseService.getCourseById(courseId);
        
        notificationService.sendEmail(user.getEmail(), "Payment Confirmation", 
            "Payment of ₹" + amount + " for " + course.getTitle() + " successful.\nTransaction ID: " + transactionId);
        
        return ResponseEntity.ok(Map.of("success", true, "transactionId", transactionId));
    }
}