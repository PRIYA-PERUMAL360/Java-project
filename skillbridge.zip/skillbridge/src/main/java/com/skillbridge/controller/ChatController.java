package com.skillbridge.controller;

import com.skillbridge.model.ChatMessage;
import com.skillbridge.service.ChatService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class ChatController {
    
    @Autowired
    private ChatService chatService;
    
    @PostMapping("/send-message")
    public ResponseEntity<?> sendMessage(@RequestBody Map<String, Object> request) {
        int fromUser = (int) request.get("fromUser");
        int toUser = (int) request.get("toUser");
        String message = (String) request.get("message");
        
        ChatMessage chatMessage = chatService.sendMessage(fromUser, toUser, message);
        return ResponseEntity.ok(Map.of("success", true, "message", chatMessage));
    }
    
    @GetMapping("/chats/{user1}/{user2}")
    public ResponseEntity<List<ChatMessage>> getChats(@PathVariable int user1, @PathVariable int user2) {
        return ResponseEntity.ok(chatService.getConversation(user1, user2));
    }
    
    @PostMapping("/mark-read/{userId}/{otherUserId}")
    public ResponseEntity<?> markAsRead(@PathVariable int userId, @PathVariable int otherUserId) {
        chatService.markMessagesAsRead(userId, otherUserId);
        return ResponseEntity.ok(Map.of("success", true));
    }
}