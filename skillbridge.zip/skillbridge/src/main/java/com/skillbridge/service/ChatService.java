package com.skillbridge.service;

import com.skillbridge.model.ChatMessage;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

@Service
public class ChatService {
    
    private final Map<Integer, ChatMessage> messages = new ConcurrentHashMap<>();
    private int nextId = 1;
    
    public ChatMessage sendMessage(int fromUser, int toUser, String message) {
        ChatMessage chatMessage = new ChatMessage();
        chatMessage.setId(nextId++);
        chatMessage.setFromUser(fromUser);
        chatMessage.setToUser(toUser);
        chatMessage.setMessage(message);
        chatMessage.setTimestamp(new Date());
        chatMessage.setRead(false);
        messages.put(chatMessage.getId(), chatMessage);
        return chatMessage;
    }
    
    public List<ChatMessage> getConversation(int user1, int user2) {
        return messages.values().stream()
                .filter(m -> (m.getFromUser() == user1 && m.getToUser() == user2) ||
                            (m.getFromUser() == user2 && m.getToUser() == user1))
                .sorted(Comparator.comparing(ChatMessage::getTimestamp))
                .collect(Collectors.toList());
    }
    
    public void markMessagesAsRead(int userId, int otherUserId) {
        messages.values().stream()
                .filter(m -> m.getToUser() == userId && m.getFromUser() == otherUserId)
                .forEach(m -> m.setRead(true));
    }
}