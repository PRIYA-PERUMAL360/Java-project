package com.skillbridge.service;

import com.skillbridge.model.Course;
import com.skillbridge.model.ScheduledClass;
import com.skillbridge.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class CourseService {
    
    private final Map<Integer, Course> courses = new ConcurrentHashMap<>();
    private final Map<Integer, ScheduledClass> scheduledClasses = new ConcurrentHashMap<>();
    private int nextScheduleId = 1;
    
    @Autowired
    private UserService userService;
    
    @Autowired
    private NotificationService notificationService;
    
    public CourseService() {
        courses.put(1, new Course(1, "React Masterclass 2024", 2, "Priya Sharma", "8 weeks", "Intermediate", 499, "Learn React from basics to advanced"));
        courses.put(2, new Course(2, "Spring Boot Framework", 2, "Priya Sharma", "6 weeks", "Intermediate", 399, "Master Spring Boot and build REST APIs"));
        courses.put(3, new Course(3, "Data Science Fundamentals", 3, "Rajesh Mehta", "10 weeks", "Advanced", 799, "Complete data science with Python"));
    }
    
    public List<Course> getAllCourses() { return new ArrayList<>(courses.values()); }
    public Course getCourseById(int id) { return courses.get(id); }
    
    public void enrollCourse(int userId, int courseId) {
        User user = userService.getUserById(userId);
        Course course = courses.get(courseId);
        if (user == null || course == null) throw new RuntimeException("User or course not found");
        if (!user.getEnrolledCourses().contains(courseId)) {
            user.getEnrolledCourses().add(courseId);
            course.setEnrolled(course.getEnrolled() + 1);
        }
    }
    
    public ScheduledClass scheduleClass(int userId, int courseId, String scheduledDateTime, String timezone) {
        User user = userService.getUserById(userId);
        Course course = courses.get(courseId);
        if (user == null || course == null) throw new RuntimeException("User or course not found");
        
        ScheduledClass scheduledClass = new ScheduledClass();
        scheduledClass.setId(nextScheduleId++);
        scheduledClass.setUserId(userId);
        scheduledClass.setCourseId(courseId);
        scheduledClass.setCourseName(course.getTitle());
        
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
            scheduledClass.setScheduledDateTime(sdf.parse(scheduledDateTime));
        } catch (Exception e) {
            scheduledClass.setScheduledDateTime(new Date());
        }
        
        scheduledClass.setTimezone(timezone);
        scheduledClass.setMeetLink("https://meet.google.com/" + UUID.randomUUID().toString().substring(0, 8));
        scheduledClass.setStatus("scheduled");
        scheduledClasses.put(scheduledClass.getId(), scheduledClass);
        
        notificationService.sendEmail(user.getEmail(), "Class Scheduled: " + course.getTitle(), 
            "Your class is scheduled at " + scheduledDateTime + "\nJoin Link: " + scheduledClass.getMeetLink());
        
        return scheduledClass;
    }
    
    public List<ScheduledClass> getUserClasses(int userId) {
        return scheduledClasses.values().stream().filter(c -> c.getUserId() == userId).toList();
    }
    
    public Map<String, Object> handleTabViolation(int userId, int courseId) {
        User user = userService.getUserById(userId);
        if (user == null || !"learner".equals(user.getRole())) return Map.of("blocked", false);
        
        int newCount = user.getTabSwitches() + 1;
        user.setTabSwitches(newCount);
        int remaining = Math.max(0, 5 - newCount);
        
        notificationService.sendEmail(user.getEmail(), "Tab Switch Warning", 
            "You have switched tabs " + newCount + " time(s). Remaining: " + remaining);
        
        if (newCount >= 5) {
            user.setBlocked(true);
            user.getEnrolledCourses().remove(Integer.valueOf(courseId));
            notificationService.sendEmail(user.getEmail(), "Course Access Blocked", 
                "You have been blocked from the course due to excessive tab switching.");
            return Map.of("blocked", true, "remaining", 0);
        }
        return Map.of("blocked", false, "remaining", remaining, "tabSwitches", newCount);
    }
    
    public Map<String, Object> completeCourse(int userId, int courseId, Integer rating, String review) {
        User user = userService.getUserById(userId);
        Course course = courses.get(courseId);
        if (user == null) throw new RuntimeException("User not found");
        if (user.getTabSwitches() >= 5) throw new RuntimeException("Certification denied due to tab violations");
        
        if (!user.getCompletedCourses().contains(courseId)) {
            user.getCompletedCourses().add(courseId);
            Map<String, Object> certificate = new HashMap<>();
            certificate.put("courseId", courseId);
            certificate.put("courseName", course.getTitle());
            certificate.put("issuedDate", new Date().toString());
            certificate.put("certificateId", "SB-" + System.currentTimeMillis() + "-" + userId);
            user.getCertifications().add(certificate);
            notificationService.sendEmail(user.getEmail(), "Course Completed!", "Certificate ID: " + certificate.get("certificateId"));
            
            if (rating != null && course != null) {
                double newRating = (course.getRating() * course.getEnrolled() + rating) / (course.getEnrolled() + 1);
                course.setRating(Math.round(newRating * 10) / 10.0);
            }
            return Map.of("success", true, "certificate", certificate);
        }
        return Map.of("success", true, "message", "Already completed");
    }
}