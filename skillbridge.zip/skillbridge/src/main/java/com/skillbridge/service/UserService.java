package com.skillbridge.service;

import com.skillbridge.model.User;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

@Service
public class UserService {
    
    private final Map<Integer, User> users = new ConcurrentHashMap<>();
    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
    private int nextId = 4;
    
    public UserService() {
        // Demo User 1 - Learner
        User user1 = new User();
        user1.setId(1);
        user1.setName("Alex Kumar");
        user1.setEmail("alex@skillbridge.com");
        user1.setPhone("+919876543210");
        user1.setPassword(passwordEncoder.encode("123456"));
        user1.setRole("learner");
        user1.setJoinDate("January 2024");
        
        Map<String, Object> location1 = new HashMap<>();
        location1.put("lat", 19.0760);
        location1.put("lng", 72.8777);
        location1.put("address", "Mumbai, India");
        user1.setLocation(location1);
        
        Map<String, Object> profile1 = new HashMap<>();
        profile1.put("headline", "Full Stack Developer");
        profile1.put("bio", "Passionate learner");
        profile1.put("skills", Arrays.asList("React", "Node.js"));
        user1.setProfile(profile1);
        
        users.put(1, user1);
        
        // Demo User 2 - Teacher
        User user2 = new User();
        user2.setId(2);
        user2.setName("Priya Sharma");
        user2.setEmail("priya@skillbridge.com");
        user2.setPhone("+919876543211");
        user2.setPassword(passwordEncoder.encode("123456"));
        user2.setRole("teacher");
        user2.setJoinDate("January 2024");
        
        Map<String, Object> location2 = new HashMap<>();
        location2.put("lat", 19.0780);
        location2.put("lng", 72.8800);
        location2.put("address", "Andheri, Mumbai");
        user2.setLocation(location2);
        
        Map<String, Object> profile2 = new HashMap<>();
        profile2.put("headline", "Senior Instructor");
        profile2.put("bio", "5+ years experience");
        profile2.put("skills", Arrays.asList("React", "Python"));
        user2.setProfile(profile2);
        
        users.put(2, user2);
        
        // Demo User 3 - Teacher
        User user3 = new User();
        user3.setId(3);
        user3.setName("Rajesh Mehta");
        user3.setEmail("rajesh@skillbridge.com");
        user3.setPhone("+919876543212");
        user3.setPassword(passwordEncoder.encode("123456"));
        user3.setRole("teacher");
        user3.setJoinDate("February 2024");
        
        Map<String, Object> location3 = new HashMap<>();
        location3.put("lat", 19.0820);
        location3.put("lng", 72.8850);
        location3.put("address", "Bandra, Mumbai");
        user3.setLocation(location3);
        
        Map<String, Object> profile3 = new HashMap<>();
        profile3.put("headline", "Data Science Expert");
        profile3.put("bio", "AI/ML specialist");
        profile3.put("skills", Arrays.asList("Python", "TensorFlow"));
        user3.setProfile(profile3);
        
        users.put(3, user3);
    }
    
    public User signup(String name, String email, String phone, String rawPassword, String role) {
        if (findByEmail(email) != null) {
            throw new RuntimeException("User already exists");
        }
        
        User user = new User();
        user.setId(nextId++);
        user.setName(name);
        user.setEmail(email);
        user.setPhone(phone);
        user.setPassword(passwordEncoder.encode(rawPassword));
        user.setRole(role);
        user.setJoinDate(new Date().toString());
        
        Map<String, Object> location = new HashMap<>();
        location.put("lat", 19.0760);
        location.put("lng", 72.8777);
        location.put("address", "Mumbai, India");
        user.setLocation(location);
        
        Map<String, Object> profile = new HashMap<>();
        profile.put("headline", role.equals("teacher") ? "Expert Teacher" : "Aspiring Learner");
        profile.put("bio", "Hello! I'm " + name);
        profile.put("skills", new ArrayList<>());
        user.setProfile(profile);
        
        users.put(user.getId(), user);
        return user;
    }
    
    public User login(String email, String password) {
        User user = findByEmail(email);
        if (user == null) throw new RuntimeException("Invalid credentials");
        if (user.isBlocked()) throw new RuntimeException("Account blocked");
        if (!passwordEncoder.matches(password, user.getPassword())) throw new RuntimeException("Invalid credentials");
        return user;
    }
    
    public User getUserById(int id) { return users.get(id); }
    
    public User findByEmail(String email) {
        return users.values().stream().filter(u -> u.getEmail().equals(email)).findFirst().orElse(null);
    }
    
    public User updateUser(int id, Map<String, Object> updates) {
        User user = users.get(id);
        if (user == null) return null;
        
        if (updates.containsKey("name")) user.setName((String) updates.get("name"));
        if (updates.containsKey("phone")) user.setPhone((String) updates.get("phone"));
        if (updates.containsKey("profile")) {
            @SuppressWarnings("unchecked")
            Map<String, Object> profileUpdates = (Map<String, Object>) updates.get("profile");
            Map<String, Object> currentProfile = user.getProfile();
            if (currentProfile == null) currentProfile = new HashMap<>();
            currentProfile.putAll(profileUpdates);
            user.setProfile(currentProfile);
        }
        if (updates.containsKey("location")) {
            @SuppressWarnings("unchecked")
            Map<String, Object> locationUpdates = (Map<String, Object>) updates.get("location");
            Map<String, Object> currentLocation = user.getLocation();
            if (currentLocation == null) currentLocation = new HashMap<>();
            currentLocation.putAll(locationUpdates);
            user.setLocation(currentLocation);
        }
        return user;
    }
    
    public User updateProfilePic(int userId, String profilePicPath) {
        User user = users.get(userId);
        if (user != null) user.setProfilePic(profilePicPath);
        return user;
    }
    
    public List<User> getNearbyUsers(int userId, int radius) {
        User currentUser = users.get(userId);
        if (currentUser == null || currentUser.getLocation() == null) return new ArrayList<>();
        
        double currentLat = (double) currentUser.getLocation().get("lat");
        double currentLng = (double) currentUser.getLocation().get("lng");
        
        return users.values().stream()
                .filter(u -> u.getId() != userId && u.getLocation() != null)
                .map(u -> {
                    double lat = (double) u.getLocation().get("lat");
                    double lng = (double) u.getLocation().get("lng");
                    double distance = Math.abs(lat - currentLat) * 100 + Math.abs(lng - currentLng) * 100;
                    u.getLocation().put("distance", distance);
                    return u;
                })
                .filter(u -> (double) u.getLocation().get("distance") <= radius)
                .sorted((a, b) -> Double.compare((double) a.getLocation().get("distance"), (double) b.getLocation().get("distance")))
                .collect(Collectors.toList());
    }
    
    public List<User> getTeachers() {
        return users.values().stream().filter(u -> "teacher".equals(u.getRole())).collect(Collectors.toList());
    }
    
    public List<Integer> getTeacherCourses(int teacherId) { return new ArrayList<>(); }
}