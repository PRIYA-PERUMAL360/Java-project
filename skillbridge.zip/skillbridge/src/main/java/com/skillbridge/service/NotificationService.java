package com.skillbridge.service;

import org.springframework.stereotype.Service;

@Service
public class NotificationService {
    
    public void sendEmail(String to, String subject, String message) {
        System.out.println("\n📧 =========================================");
        System.out.println("   EMAIL NOTIFICATION");
        System.out.println("   =========================================");
        System.out.println("   To: " + to);
        System.out.println("   Subject: " + subject);
        System.out.println("   Message: " + message);
        System.out.println("   =========================================\n");
    }
    
    public void sendSMS(String phone, String message) {
        System.out.println("📱 SMS to " + phone + ": " + message);
    }
}