package com.skillbridge;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication(exclude = {SecurityAutoConfiguration.class})
@EnableScheduling
public class SkillBridgeConnectApplication {
    public static void main(String[] args) {
        SpringApplication.run(SkillBridgeConnectApplication.class, args);
        System.out.println("\n✅ =========================================");
        System.out.println("   SKILLBRIDGECONNECT SERVER RUNNING");
        System.out.println("   =========================================");
        System.out.println("   🚀 Server: http://localhost:8080");
        System.out.println("   👥 Demo: alex@skillbridge.com / 123456");
        System.out.println("   =========================================\n");
    }
}