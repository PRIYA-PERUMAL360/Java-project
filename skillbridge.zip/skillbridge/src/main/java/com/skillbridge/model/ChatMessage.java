package com.skillbridge.model;

import java.util.Date;

public class ChatMessage {
    private int id;
    private int fromUser;
    private int toUser;
    private String message;
    private Date timestamp;
    private boolean read;
    
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getFromUser() { return fromUser; }
    public void setFromUser(int fromUser) { this.fromUser = fromUser; }
    public int getToUser() { return toUser; }
    public void setToUser(int toUser) { this.toUser = toUser; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
    public Date getTimestamp() { return timestamp; }
    public void setTimestamp(Date timestamp) { this.timestamp = timestamp; }
    public boolean isRead() { return read; }
    public void setRead(boolean read) { this.read = read; }
}