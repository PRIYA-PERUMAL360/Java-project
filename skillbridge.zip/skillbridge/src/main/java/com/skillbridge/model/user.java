package com.skillbridge.model;

import java.util.*;

public class User {
    private int id;
    private String name;
    private String email;
    private String phone;
    private String password;
    private String role;
    private String joinDate;
    private String profilePic;
    private Map<String, Object> location;
    private Map<String, Object> profile;
    private List<Integer> enrolledCourses;
    private List<Integer> completedCourses;
    private List<Map<String, Object>> certifications;
    private int tabSwitches;
    private boolean isBlocked;
    private List<Integer> courses;
    
    public User() {
        this.enrolledCourses = new ArrayList<>();
        this.completedCourses = new ArrayList<>();
        this.certifications = new ArrayList<>();
        this.tabSwitches = 0;
        this.isBlocked = false;
    }
    
    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    
    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }
    
    public String getJoinDate() { return joinDate; }
    public void setJoinDate(String joinDate) { this.joinDate = joinDate; }
    
    public String getProfilePic() { return profilePic; }
    public void setProfilePic(String profilePic) { this.profilePic = profilePic; }
    
    public Map<String, Object> getLocation() { return location; }
    public void setLocation(Map<String, Object> location) { this.location = location; }
    
    public Map<String, Object> getProfile() { return profile; }
    public void setProfile(Map<String, Object> profile) { this.profile = profile; }
    
    public List<Integer> getEnrolledCourses() { return enrolledCourses; }
    public void setEnrolledCourses(List<Integer> enrolledCourses) { this.enrolledCourses = enrolledCourses; }
    
    public List<Integer> getCompletedCourses() { return completedCourses; }
    public void setCompletedCourses(List<Integer> completedCourses) { this.completedCourses = completedCourses; }
    
    public List<Map<String, Object>> getCertifications() { return certifications; }
    public void setCertifications(List<Map<String, Object>> certifications) { this.certifications = certifications; }
    
    public int getTabSwitches() { return tabSwitches; }
    public void setTabSwitches(int tabSwitches) { this.tabSwitches = tabSwitches; }
    
    public boolean isBlocked() { return isBlocked; }
    public void setBlocked(boolean blocked) { isBlocked = blocked; }
    
    public List<Integer> getCourses() { return courses; }
    public void setCourses(List<Integer> courses) { this.courses = courses; }
}