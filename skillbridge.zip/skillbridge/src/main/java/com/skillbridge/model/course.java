package com.skillbridge.model;

public class Course {
    private int id;
    private String title;
    private int teacherId;
    private String teacher;
    private String duration;
    private String level;
    private int price;
    private int enrolled;
    private double rating;
    private String description;
    
    public Course() {}
    
    public Course(int id, String title, int teacherId, String teacher, String duration, 
                  String level, int price, String description) {
        this.id = id;
        this.title = title;
        this.teacherId = teacherId;
        this.teacher = teacher;
        this.duration = duration;
        this.level = level;
        this.price = price;
        this.description = description;
        this.enrolled = 0;
        this.rating = 0;
    }
    
    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public int getTeacherId() { return teacherId; }
    public void setTeacherId(int teacherId) { this.teacherId = teacherId; }
    public String getTeacher() { return teacher; }
    public void setTeacher(String teacher) { this.teacher = teacher; }
    public String getDuration() { return duration; }
    public void setDuration(String duration) { this.duration = duration; }
    public String getLevel() { return level; }
    public void setLevel(String level) { this.level = level; }
    public int getPrice() { return price; }
    public void setPrice(int price) { this.price = price; }
    public int getEnrolled() { return enrolled; }
    public void setEnrolled(int enrolled) { this.enrolled = enrolled; }
    public double getRating() { return rating; }
    public void setRating(double rating) { this.rating = rating; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
}