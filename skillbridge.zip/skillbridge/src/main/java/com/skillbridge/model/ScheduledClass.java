package com.skillbridge.model;

import java.util.Date;

public class ScheduledClass {
    private int id;
    private int userId;
    private int courseId;
    private String courseName;
    private Date scheduledDateTime;
    private String timezone;
    private String meetLink;
    private String status;
    
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }
    public int getCourseId() { return courseId; }
    public void setCourseId(int courseId) { this.courseId = courseId; }
    public String getCourseName() { return courseName; }
    public void setCourseName(String courseName) { this.courseName = courseName; }
    public Date getScheduledDateTime() { return scheduledDateTime; }
    public void setScheduledDateTime(Date scheduledDateTime) { this.scheduledDateTime = scheduledDateTime; }
    public String getTimezone() { return timezone; }
    public void setTimezone(String timezone) { this.timezone = timezone; }
    public String getMeetLink() { return meetLink; }
    public void setMeetLink(String meetLink) { this.meetLink = meetLink; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}