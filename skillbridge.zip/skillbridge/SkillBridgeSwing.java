import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.net.http.*;
import java.net.URI;
import java.util.*;
import java.util.List;

public class SkillBridgeSwing extends JFrame {
    
    // API Configuration
    private static final String BASE_URL = "http://localhost:8888";    
    // Current logged in user
    private Map<String, Object> currentUser = new HashMap<>();
    
    // Main UI Components
    private CardLayout cardLayout;
    private JPanel mainPanel;
    
    // Dashboard Components
    private JLabel profileNameLabel;
    private JLabel enrolledCountLabel;
    private JLabel completedCountLabel;
    private JLabel totalSpentLabel;
    private JPanel dynamicContentPanel;
    private JPanel recentActivityPanel;
    private JButton learnBtn;
    private JButton teachBtn;
    
    // Auth Components
    private JTextField loginEmailField;
    private JPasswordField loginPasswordField;
    private JTextField signupNameField;
    private JTextField signupEmailField;
    private JTextField signupPhoneField;
    private JTextField signupDobField;
    private JPasswordField signupPasswordField;
    private JPasswordField signupConfirmField;
    private JComboBox<String> signupRoleCombo;
    
    // Profile Modal Components
    private JDialog profileDialog;
    private JTextField editNameField;
    private JTextField editHeadlineField;
    private JTextArea editBioArea;
    private JTextField editAddressField;
    private JTextField editCompanyField;
    private JTextField editPositionField;
    private JTextField editSkillsField;
    private JTextField editProfilePicField;
    private JTextField editTeachingCostField;
    
    // Book Session Modal
    private JDialog bookDialog;
    private JTextField bookTeacherNameField;
    private JTextField bookTeacherEmailField;
    private JTextField bookAmountField;
    private JComboBox<String> bookDateCombo;
    private JComboBox<String> bookTimeCombo;
    private String currentBookingTeacherEmail;
    private double currentBookingAmount;
    
    // Chatbot Dialog
    private JDialog chatbotDialog;
    private JTextArea chatbotTextArea;
    private JTextField chatbotInputField;
    
    public SkillBridgeSwing() {
        setTitle("SkillBridge Connect");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 700);
        setLocationRelativeTo(null);
        setMinimumSize(new Dimension(1000, 600));
        
        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);
        mainPanel.add(createAuthPanel(), "auth");
        mainPanel.add(createDashboardPanel(), "dashboard");
        add(mainPanel);
        cardLayout.show(mainPanel, "auth");
    }
    
    private JPanel createAuthPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(243, 242, 239));
        
        JPanel card = new JPanel();
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(224, 224, 224)),
            BorderFactory.createEmptyBorder(30, 30, 30, 30)
        ));
        card.setPreferredSize(new Dimension(400, 550));
        card.setLayout(new BorderLayout());
        
        JLabel titleLabel = new JLabel("🎓 SkillBridge Connect");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        titleLabel.setForeground(new Color(102, 126, 234));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        card.add(titleLabel, BorderLayout.NORTH);
        
        JPanel tabsPanel = new JPanel(new GridLayout(1, 2, 10, 0));
        JButton loginTab = new JButton("Login");
        JButton signupTab = new JButton("Sign Up");
        loginTab.setBackground(new Color(102, 126, 234));
        loginTab.setForeground(Color.WHITE);
        signupTab.setBackground(new Color(240, 240, 240));
        tabsPanel.add(loginTab);
        tabsPanel.add(signupTab);
        card.add(tabsPanel, BorderLayout.CENTER);
        
        JPanel loginPanel = new JPanel(new GridBagLayout());
        loginPanel.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(8, 20, 8, 20);
        
        gbc.gridy = 0;
        loginPanel.add(new JLabel("Email"), gbc);
        gbc.gridy = 1;
        loginEmailField = new JTextField("learner@skillbridge.com");
        loginEmailField.setPreferredSize(new Dimension(340, 35));
        loginPanel.add(loginEmailField, gbc);
        
        gbc.gridy = 2;
        loginPanel.add(new JLabel("Password"), gbc);
        gbc.gridy = 3;
        loginPasswordField = new JPasswordField("learner123");
        loginPasswordField.setPreferredSize(new Dimension(340, 35));
        loginPanel.add(loginPasswordField, gbc);
        
        gbc.gridy = 4;
        JButton fingerprintBtn = new JButton("🖐️ Login with Fingerprint");
        fingerprintBtn.addActionListener(e -> loginWithFingerprint());
        loginPanel.add(fingerprintBtn, gbc);
        
        gbc.gridy = 5;
        JButton loginBtn = new JButton("Login");
        loginBtn.setBackground(new Color(102, 126, 234));
        loginBtn.setForeground(Color.WHITE);
        loginBtn.addActionListener(e -> login());
        loginPanel.add(loginBtn, gbc);
        
        gbc.gridy = 6;
        JLabel demoLabel = new JLabel("Demo: learner@skillbridge.com / learner123");
        demoLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        demoLabel.setForeground(Color.GRAY);
        loginPanel.add(demoLabel, gbc);
        
        JPanel signupPanel = new JPanel(new GridBagLayout());
        signupPanel.setBackground(Color.WHITE);
        signupPanel.setVisible(false);
        GridBagConstraints sgbc = new GridBagConstraints();
        sgbc.gridx = 0;
        sgbc.fill = GridBagConstraints.HORIZONTAL;
        sgbc.insets = new Insets(5, 20, 5, 20);
        
        sgbc.gridy = 0;
        signupPanel.add(new JLabel("Full Name"), sgbc);
        sgbc.gridy = 1;
        signupNameField = new JTextField();
        signupNameField.setPreferredSize(new Dimension(340, 30));
        signupPanel.add(signupNameField, sgbc);
        
        sgbc.gridy = 2;
        signupPanel.add(new JLabel("Email"), sgbc);
        sgbc.gridy = 3;
        signupEmailField = new JTextField();
        signupEmailField.setPreferredSize(new Dimension(340, 30));
        signupPanel.add(signupEmailField, sgbc);
        
        sgbc.gridy = 4;
        signupPanel.add(new JLabel("Phone"), sgbc);
        sgbc.gridy = 5;
        signupPhoneField = new JTextField();
        signupPhoneField.setPreferredSize(new Dimension(340, 30));
        signupPanel.add(signupPhoneField, sgbc);
        
        sgbc.gridy = 6;
        signupPanel.add(new JLabel("Date of Birth (YYYY-MM-DD)"), sgbc);
        sgbc.gridy = 7;
        signupDobField = new JTextField();
        signupDobField.setPreferredSize(new Dimension(340, 30));
        signupPanel.add(signupDobField, sgbc);
        
        sgbc.gridy = 8;
        signupPanel.add(new JLabel("Password"), sgbc);
        sgbc.gridy = 9;
        signupPasswordField = new JPasswordField();
        signupPasswordField.setPreferredSize(new Dimension(340, 30));
        signupPanel.add(signupPasswordField, sgbc);
        
        sgbc.gridy = 10;
        signupPanel.add(new JLabel("Confirm Password"), sgbc);
        sgbc.gridy = 11;
        signupConfirmField = new JPasswordField();
        signupConfirmField.setPreferredSize(new Dimension(340, 30));
        signupPanel.add(signupConfirmField, sgbc);
        
        sgbc.gridy = 12;
        signupPanel.add(new JLabel("I want to"), sgbc);
        sgbc.gridy = 13;
        signupRoleCombo = new JComboBox<>(new String[]{"learner", "teacher"});
        signupRoleCombo.setPreferredSize(new Dimension(340, 30));
        signupPanel.add(signupRoleCombo, sgbc);
        
        sgbc.gridy = 14;
        JButton signupBtn = new JButton("Create Account");
        signupBtn.setBackground(new Color(102, 126, 234));
        signupBtn.setForeground(Color.WHITE);
        signupBtn.addActionListener(e -> signup());
        signupPanel.add(signupBtn, sgbc);
        
        JPanel formsPanel = new JPanel(new CardLayout());
        formsPanel.add(loginPanel, "login");
        formsPanel.add(signupPanel, "signup");
        card.add(formsPanel, BorderLayout.SOUTH);
        
        loginTab.addActionListener(e -> {
            loginTab.setBackground(new Color(102, 126, 234));
            loginTab.setForeground(Color.WHITE);
            signupTab.setBackground(new Color(240, 240, 240));
            signupTab.setForeground(Color.BLACK);
            ((CardLayout)formsPanel.getLayout()).show(formsPanel, "login");
        });
        
        signupTab.addActionListener(e -> {
            signupTab.setBackground(new Color(102, 126, 234));
            signupTab.setForeground(Color.WHITE);
            loginTab.setBackground(new Color(240, 240, 240));
            loginTab.setForeground(Color.BLACK);
            ((CardLayout)formsPanel.getLayout()).show(formsPanel, "signup");
        });
        
        panel.add(card);
        return panel;
    }
    
    private JPanel createDashboardPanel() {
        JPanel mainDashPanel = new JPanel(new BorderLayout());
        mainDashPanel.setBackground(new Color(243, 242, 239));
        
        // Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(Color.WHITE);
        headerPanel.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(224, 224, 224)));
        headerPanel.setPreferredSize(new Dimension(0, 60));
        
        JPanel headerContent = new JPanel(new BorderLayout());
        headerContent.setBackground(Color.WHITE);
        headerContent.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 20));
        
        JLabel logoLabel = new JLabel("🎓 SkillBridge Connect");
        logoLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        logoLabel.setForeground(new Color(102, 126, 234));
        headerContent.add(logoLabel, BorderLayout.WEST);
        
        JPanel navPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20, 10));
        navPanel.setBackground(Color.WHITE);
        
        String[] navItems = {"🏠 Home", "📚 Courses", "🔍 Find Teachers", "📅 Bookings", "💰 Payments", "🔔 Notifications", "👤 Profile", "🚪 Logout"};
        for (String item : navItems) {
            JButton navBtn = new JButton(item);
            navBtn.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            navBtn.setBorderPainted(false);
            navBtn.setBackground(Color.WHITE);
            navBtn.addActionListener(e -> {
                if (item.equals("🚪 Logout")) logout();
                else if (item.equals("🏠 Home")) showHome();
                else if (item.equals("📚 Courses")) showCourses();
                else if (item.equals("🔍 Find Teachers")) showSearchTeachers();
                else if (item.equals("📅 Bookings")) showBookings();
                else if (item.equals("💰 Payments")) showPayments();
                else if (item.equals("🔔 Notifications")) showNotifications();
                else if (item.equals("👤 Profile")) showProfileModal();
            });
            navPanel.add(navBtn);
        }
        headerContent.add(navPanel, BorderLayout.EAST);
        headerPanel.add(headerContent);
        mainDashPanel.add(headerPanel, BorderLayout.NORTH);
        
        // Main Content
        JPanel contentPanel = new JPanel(new GridBagLayout());
        contentPanel.setBackground(new Color(243, 242, 239));
        contentPanel.setBorder(BorderFactory.createEmptyBorder(24, 20, 24, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(0, 12, 0, 12);
        
        JPanel leftSidebar = createLeftSidebar();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0.25;
        gbc.fill = GridBagConstraints.BOTH;
        contentPanel.add(leftSidebar, gbc);
        
        dynamicContentPanel = new JPanel();
        dynamicContentPanel.setLayout(new BoxLayout(dynamicContentPanel, BoxLayout.Y_AXIS));
        dynamicContentPanel.setBackground(new Color(243, 242, 239));
        JScrollPane middleScroll = new JScrollPane(dynamicContentPanel);
        middleScroll.setBorder(null);
        gbc.gridx = 1;
        gbc.weightx = 0.5;
        gbc.fill = GridBagConstraints.BOTH;
        contentPanel.add(middleScroll, gbc);
        
        JPanel rightSidebar = createRightSidebar();
        gbc.gridx = 2;
        gbc.weightx = 0.25;
        gbc.fill = GridBagConstraints.BOTH;
        contentPanel.add(rightSidebar, gbc);
        
        mainDashPanel.add(contentPanel, BorderLayout.CENTER);
        
        // Chatbot Button
        JButton chatbotBtn = new JButton("💬");
        chatbotBtn.setFont(new Font("Segoe UI", Font.PLAIN, 24));
        chatbotBtn.setBackground(new Color(102, 126, 234));
        chatbotBtn.setForeground(Color.WHITE);
        chatbotBtn.addActionListener(e -> showChatbot());
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottomPanel.setOpaque(false);
        bottomPanel.add(chatbotBtn);
        mainDashPanel.add(bottomPanel, BorderLayout.SOUTH);
        
        return mainDashPanel;
    }
    
    private JPanel createLeftSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(Color.WHITE);
        sidebar.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(224, 224, 224)),
            BorderFactory.createEmptyBorder(0, 0, 12, 0)
        ));
        
        JPanel profileCard = new JPanel();
        profileCard.setLayout(new BoxLayout(profileCard, BoxLayout.Y_AXIS));
        profileCard.setBackground(Color.WHITE);
        
        JPanel coverPhoto = new JPanel();
        coverPhoto.setBackground(new Color(102, 126, 234));
        coverPhoto.setPreferredSize(new Dimension(0, 60));
        profileCard.add(coverPhoto);
        
        JPanel avatarPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        avatarPanel.setBackground(Color.WHITE);
        JLabel avatarLabel = new JLabel("👨‍💻");
        avatarLabel.setFont(new Font("Segoe UI", Font.PLAIN, 36));
        avatarPanel.add(avatarLabel);
        profileCard.add(avatarPanel);
        
        profileNameLabel = new JLabel("Loading...");
        profileNameLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        profileNameLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        profileCard.add(profileNameLabel);
        
        JPanel statsPanel = new JPanel(new GridLayout(3, 2, 10, 8));
        statsPanel.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        statsPanel.add(new JLabel("📚 Enrolled"));
        enrolledCountLabel = new JLabel("0");
        statsPanel.add(enrolledCountLabel);
        statsPanel.add(new JLabel("✅ Completed"));
        completedCountLabel = new JLabel("0");
        statsPanel.add(completedCountLabel);
        statsPanel.add(new JLabel("💰 Spent"));
        totalSpentLabel = new JLabel("₹0");
        statsPanel.add(totalSpentLabel);
        profileCard.add(statsPanel);
        sidebar.add(profileCard);
        sidebar.add(Box.createVerticalStrut(12));
        
        JPanel rolePanel = new JPanel();
        rolePanel.setLayout(new BoxLayout(rolePanel, BoxLayout.Y_AXIS));
        rolePanel.setBackground(Color.WHITE);
        rolePanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(224, 224, 224)),
            BorderFactory.createEmptyBorder(12, 12, 12, 12)
        ));
        
        rolePanel.add(new JLabel("I want to"));
        JPanel roleBtns = new JPanel(new GridLayout(1, 2, 12, 0));
        learnBtn = new JButton("📚 Learn");
        teachBtn = new JButton("👨‍🏫 Teach");
        learnBtn.addActionListener(e -> setRole("learner"));
        teachBtn.addActionListener(e -> setRole("teacher"));
        roleBtns.add(learnBtn);
        roleBtns.add(teachBtn);
        rolePanel.add(roleBtns);
        sidebar.add(rolePanel);
        sidebar.add(Box.createVerticalStrut(12));
        
        JPanel actionsPanel = new JPanel();
        actionsPanel.setLayout(new BoxLayout(actionsPanel, BoxLayout.Y_AXIS));
        actionsPanel.setBackground(Color.WHITE);
        actionsPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(224, 224, 224)),
            BorderFactory.createEmptyBorder(12, 12, 12, 12)
        ));
        
        actionsPanel.add(new JLabel("💬 Quick Actions"));
        JButton aiBtn = new JButton("🤖 AI Assistant");
        aiBtn.addActionListener(e -> showChatbot());
        actionsPanel.add(aiBtn);
        actionsPanel.add(Box.createVerticalStrut(8));
        
        JButton browseBtn = new JButton("📚 Browse Courses");
        browseBtn.addActionListener(e -> showCourses());
        actionsPanel.add(browseBtn);
        actionsPanel.add(Box.createVerticalStrut(8));
        
        JButton findBtn = new JButton("🔍 Find Teachers");
        findBtn.addActionListener(e -> showSearchTeachers());
        actionsPanel.add(findBtn);
        sidebar.add(actionsPanel);
        
        return sidebar;
    }
    
    private JPanel createRightSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(Color.WHITE);
        sidebar.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(224, 224, 224)),
            BorderFactory.createEmptyBorder(12, 12, 12, 12)
        ));
        
        sidebar.add(new JLabel("⭐ Recent Activity"));
        recentActivityPanel = new JPanel();
        recentActivityPanel.setLayout(new BoxLayout(recentActivityPanel, BoxLayout.Y_AXIS));
        recentActivityPanel.setBackground(Color.WHITE);
        sidebar.add(recentActivityPanel);
        sidebar.add(Box.createVerticalStrut(16));
        
        sidebar.add(new JLabel("📌 Quick Tips"));
        String[] tips = {
            "✅ Complete courses to earn certificates",
            "✅ Find teachers by skill",
            "✅ Book sessions at your convenience",
            "✅ Use AI assistant for help"
        };
        for (String tip : tips) {
            JLabel tipLabel = new JLabel(tip);
            tipLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
            tipLabel.setForeground(Color.GRAY);
            sidebar.add(tipLabel);
            sidebar.add(Box.createVerticalStrut(5));
        }
        return sidebar;
    }
    
    // Helper method to extract value from JSON string
    private String extractValue(String json, String key) {
        String searchKey = "\"" + key + "\":";
        int startIndex = json.indexOf(searchKey);
        if (startIndex == -1) return "";
        startIndex += searchKey.length();
        while (startIndex < json.length() && (json.charAt(startIndex) == ' ' || json.charAt(startIndex) == '\t' || json.charAt(startIndex) == '"')) {
            startIndex++;
        }
        int endIndex = startIndex;
        while (endIndex < json.length() && json.charAt(endIndex) != '"' && json.charAt(endIndex) != ',' && json.charAt(endIndex) != '}') {
            endIndex++;
        }
        return json.substring(startIndex, endIndex);
    }
    
    private void login() {
        String email = loginEmailField.getText().trim();
        String password = new String(loginPasswordField.getPassword());
        
        if (email.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Enter email and password", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        SwingWorker<Void, Void> worker = new SwingWorker<Void, Void>() {
            @Override
            protected Void doInBackground() {
                try {
                    HttpClient client = HttpClient.newHttpClient();
                    String jsonBody = "{\"email\":\"" + email + "\",\"password\":\"" + password + "\"}";
                    HttpRequest request = HttpRequest.newBuilder()
                        .uri(URI.create(BASE_URL + "/api/login"))
                        .header("Content-Type", "application/json")
                        .POST(HttpRequest.BodyPublishers.ofString(jsonBody))
                        .build();
                    HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
                    String body = response.body();
                    
                    if (body.contains("\"success\":true")) {
                        String name = extractValue(body, "name");
                        String role = extractValue(body, "role");
                        currentUser.put("name", name);
                        currentUser.put("email", email);
                        currentUser.put("role", role);
                        SwingUtilities.invokeLater(() -> {
                            cardLayout.show(mainPanel, "dashboard");
                            profileNameLabel.setText(name);
                            loadDashboardStats();
                            showHome();
                        });
                    } else {
                        SwingUtilities.invokeLater(() -> 
                            JOptionPane.showMessageDialog(SkillBridgeSwing.this, "Invalid credentials", "Error", JOptionPane.ERROR_MESSAGE));
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    SwingUtilities.invokeLater(() -> 
                        JOptionPane.showMessageDialog(SkillBridgeSwing.this, "Connection error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE));
                }
                return null;
            }
        };
        worker.execute();
    }
    
    private void loginWithFingerprint() {
        String email = loginEmailField.getText().trim();
        if (email.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Enter email first", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        JOptionPane.showMessageDialog(this, "🖐️ Scanning fingerprint...", "Fingerprint", JOptionPane.INFORMATION_MESSAGE);
        
        SwingWorker<Void, Void> worker = new SwingWorker<Void, Void>() {
            @Override
            protected Void doInBackground() {
                try {
                    Thread.sleep(1500);
                    String fingerprint = "fp_" + UUID.randomUUID().toString().substring(0, 10);
                    HttpClient client = HttpClient.newHttpClient();
                    String jsonBody = "{\"email\":\"" + email + "\",\"fingerprintData\":\"" + fingerprint + "\"}";
                    HttpRequest request = HttpRequest.newBuilder()
                        .uri(URI.create(BASE_URL + "/api/login-fingerprint"))
                        .header("Content-Type", "application/json")
                        .POST(HttpRequest.BodyPublishers.ofString(jsonBody))
                        .build();
                    HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
                    String body = response.body();
                    
                    if (body.contains("\"success\":true")) {
                        String name = extractValue(body, "name");
                        String role = extractValue(body, "role");
                        currentUser.put("name", name);
                        currentUser.put("email", email);
                        currentUser.put("role", role);
                        SwingUtilities.invokeLater(() -> {
                            cardLayout.show(mainPanel, "dashboard");
                            profileNameLabel.setText(name);
                            loadDashboardStats();
                            showHome();
                        });
                    } else {
                        SwingUtilities.invokeLater(() -> 
                            JOptionPane.showMessageDialog(SkillBridgeSwing.this, "Fingerprint verification failed", "Error", JOptionPane.ERROR_MESSAGE));
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return null;
            }
        };
        worker.execute();
    }
    
    private void signup() {
        String name = signupNameField.getText().trim();
        String email = signupEmailField.getText().trim();
        String phone = signupPhoneField.getText().trim();
        String dob = signupDobField.getText().trim();
        String password = new String(signupPasswordField.getPassword());
        String confirm = new String(signupConfirmField.getPassword());
        String role = (String) signupRoleCombo.getSelectedItem();
        
        if (name.isEmpty() || email.isEmpty() || phone.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all fields", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (!password.equals(confirm)) {
            JOptionPane.showMessageDialog(this, "Passwords do not match", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        SwingWorker<Void, Void> worker = new SwingWorker<Void, Void>() {
            @Override
            protected Void doInBackground() {
                try {
                    HttpClient client = HttpClient.newHttpClient();
                    String jsonBody = "{\"name\":\"" + name + "\",\"email\":\"" + email + "\",\"phone\":\"" + phone + 
                                     "\",\"password\":\"" + password + "\",\"dob\":\"" + dob + "\",\"role\":\"" + role + "\"}";
                    HttpRequest request = HttpRequest.newBuilder()
                        .uri(URI.create(BASE_URL + "/api/signup"))
                        .header("Content-Type", "application/json")
                        .POST(HttpRequest.BodyPublishers.ofString(jsonBody))
                        .build();
                    HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
                    
                    SwingUtilities.invokeLater(() -> {
                        JOptionPane.showMessageDialog(SkillBridgeSwing.this, "Account created! Please login.", "Success", JOptionPane.INFORMATION_MESSAGE);
                        loginEmailField.setText(email);
                        loginPasswordField.setText(password);
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return null;
            }
        };
        worker.execute();
    }
    
    private void setRole(String role) {
        currentUser.put("role", role);
        if ("teacher".equals(role)) {
            learnBtn.setBackground(new Color(240, 240, 240));
            teachBtn.setBackground(new Color(102, 126, 234));
            teachBtn.setForeground(Color.WHITE);
            learnBtn.setForeground(Color.BLACK);
        } else {
            learnBtn.setBackground(new Color(102, 126, 234));
            teachBtn.setBackground(new Color(240, 240, 240));
            learnBtn.setForeground(Color.WHITE);
            teachBtn.setForeground(Color.BLACK);
        }
    }
    
    private void loadDashboardStats() {
        SwingWorker<Void, Void> worker = new SwingWorker<Void, Void>() {
            @Override
            protected Void doInBackground() {
                try {
                    HttpClient client = HttpClient.newHttpClient();
                    HttpRequest request = HttpRequest.newBuilder()
                        .uri(URI.create(BASE_URL + "/api/dashboard?email=" + currentUser.get("email")))
                        .GET()
                        .build();
                    HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
                    String body = response.body();
                    
                    SwingUtilities.invokeLater(() -> {
                        String enrolled = extractValue(body, "enrolledCourses");
                        String completed = extractValue(body, "completedCourses");
                        String spent = extractValue(body, "totalSpent");
                        enrolledCountLabel.setText(enrolled.isEmpty() ? "0" : enrolled);
                        completedCountLabel.setText(completed.isEmpty() ? "0" : completed);
                        totalSpentLabel.setText("₹" + (spent.isEmpty() ? "0" : spent));
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return null;
            }
        };
        worker.execute();
    }
    
    private void showHome() {
        dynamicContentPanel.removeAll();
        
        JPanel welcomeCard = createCourseCard();
        welcomeCard.add(new JLabel("🏠 Welcome to SkillBridge Connect, " + currentUser.get("name") + "!"));
        welcomeCard.add(new JLabel("Your skill development platform. Learn new skills, connect with teachers."));
        JButton browseBtn = new JButton("Browse Courses");
        browseBtn.addActionListener(e -> showCourses());
        welcomeCard.add(browseBtn);
        JButton findBtn = new JButton("Find Teachers");
        findBtn.addActionListener(e -> showSearchTeachers());
        welcomeCard.add(findBtn);
        
        JPanel statsCard = createCourseCard();
        statsCard.add(new JLabel("📊 Your Stats"));
        statsCard.add(new JLabel("📚 Enrolled: " + enrolledCountLabel.getText()));
        statsCard.add(new JLabel("✅ Completed: " + completedCountLabel.getText()));
        statsCard.add(new JLabel("💰 Total Spent: " + totalSpentLabel.getText()));
        
        dynamicContentPanel.add(welcomeCard);
        dynamicContentPanel.add(Box.createVerticalStrut(16));
        dynamicContentPanel.add(statsCard);
        dynamicContentPanel.revalidate();
        dynamicContentPanel.repaint();
    }
    
    private void showCourses() {
        SwingWorker<Void, Void> worker = new SwingWorker<Void, Void>() {
            @Override
            protected Void doInBackground() {
                try {
                    HttpClient client = HttpClient.newHttpClient();
                    HttpRequest request = HttpRequest.newBuilder()
                        .uri(URI.create(BASE_URL + "/api/courses"))
                        .GET()
                        .build();
                    HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
                    String body = response.body();
                    
                    SwingUtilities.invokeLater(() -> {
                        dynamicContentPanel.removeAll();
                        JLabel titleLabel = new JLabel("📚 Available Courses");
                        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
                        dynamicContentPanel.add(titleLabel);
                        dynamicContentPanel.add(Box.createVerticalStrut(16));
                        
                        String[] courses = body.split("\\{");
                        for (String c : courses) {
                            if (c.contains("\"id\"")) {
                                String id = extractValue(c, "id");
                                String title = extractValue(c, "title");
                                String teacher = extractValue(c, "teacher");
                                String price = extractValue(c, "price");
                                String description = extractValue(c, "description");
                                
                                JPanel courseCard = createCourseCard();
                                courseCard.add(new JLabel("📖 " + title));
                                courseCard.add(new JLabel("👨‍🏫 " + teacher));
                                courseCard.add(new JLabel("💰 ₹" + price));
                                courseCard.add(new JLabel(description.length() > 80 ? description.substring(0, 80) + "..." : description));
                                
                                int courseId = Integer.parseInt(id);
                                int coursePrice = Integer.parseInt(price);
                                JButton enrollBtn = new JButton("Enroll Now - ₹" + price);
                                enrollBtn.addActionListener(e -> makePayment(courseId, title, coursePrice));
                                courseCard.add(enrollBtn);
                                
                                dynamicContentPanel.add(courseCard);
                                dynamicContentPanel.add(Box.createVerticalStrut(12));
                            }
                        }
                        dynamicContentPanel.revalidate();
                        dynamicContentPanel.repaint();
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return null;
            }
        };
        worker.execute();
    }
    
    private void showSearchTeachers() {
        String skill = JOptionPane.showInputDialog(this, "Enter skill to search for (e.g., React, Java, Python):");
        if (skill == null || skill.trim().isEmpty()) return;
        
        SwingWorker<Void, Void> worker = new SwingWorker<Void, Void>() {
            @Override
            protected Void doInBackground() {
                try {
                    HttpClient client = HttpClient.newHttpClient();
                    HttpRequest request = HttpRequest.newBuilder()
                        .uri(URI.create(BASE_URL + "/api/search-teachers?skill=" + skill + "&learnerEmail=" + currentUser.get("email")))
                        .GET()
                        .build();
                    HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
                    String body = response.body();
                    
                    SwingUtilities.invokeLater(() -> {
                        dynamicContentPanel.removeAll();
                        JLabel titleLabel = new JLabel("🔍 Teachers for \"" + skill + "\"");
                        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
                        dynamicContentPanel.add(titleLabel);
                        dynamicContentPanel.add(Box.createVerticalStrut(16));
                        
                        String[] teachers = body.split("\\{");
                        boolean found = false;
                        for (String t : teachers) {
                            if (t.contains("\"name\"")) {
                                found = true;
                                String name = extractValue(t, "name");
                                String email = extractValue(t, "email");
                                String headline = extractValue(t, "headline");
                                String cost = extractValue(t, "teachingCost");
                                String distance = extractValue(t, "distance");
                                String rating = extractValue(t, "rating");
                                
                                JPanel teacherCard = createCourseCard();
                                teacherCard.add(new JLabel("👨‍🏫 " + name));
                                teacherCard.add(new JLabel(headline));
                                teacherCard.add(new JLabel("⭐ Rating: " + (rating.isEmpty() ? "New" : rating) + " | 📍 " + distance + " km away"));
                                teacherCard.add(new JLabel("💰 Teaching Cost: ₹" + cost + " per session"));
                                
                                double costVal = Double.parseDouble(cost);
                                JButton bookBtn = new JButton("Book Session");
                                bookBtn.addActionListener(e -> openBookModal(name, email, costVal));
                                teacherCard.add(bookBtn);
                                
                                dynamicContentPanel.add(teacherCard);
                                dynamicContentPanel.add(Box.createVerticalStrut(12));
                            }
                        }
                        if (!found) {
                            JPanel noResults = createCourseCard();
                            noResults.add(new JLabel("No teachers found for this skill. Try another skill!"));
                            dynamicContentPanel.add(noResults);
                        }
                        dynamicContentPanel.revalidate();
                        dynamicContentPanel.repaint();
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return null;
            }
        };
        worker.execute();
    }
    
    private void showBookings() {
        JOptionPane.showMessageDialog(this, "Bookings feature - Coming soon!", "Info", JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void showPayments() {
        JOptionPane.showMessageDialog(this, "Payments feature - Coming soon!", "Info", JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void showNotifications() {
        JOptionPane.showMessageDialog(this, "Notifications feature - Coming soon!", "Info", JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void makePayment(int courseId, String courseName, int amount) {
        int confirm = JOptionPane.showConfirmDialog(this, "Pay ₹" + amount + " for " + courseName + "?", "Confirm Payment", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;
        
        SwingWorker<Void, Void> worker = new SwingWorker<Void, Void>() {
            @Override
            protected Void doInBackground() {
                try {
                    HttpClient client = HttpClient.newHttpClient();
                    String jsonBody = "{\"email\":\"" + currentUser.get("email") + "\",\"courseId\":" + courseId + ",\"amount\":" + amount + "}";
                    HttpRequest request = HttpRequest.newBuilder()
                        .uri(URI.create(BASE_URL + "/api/process-payment"))
                        .header("Content-Type", "application/json")
                        .POST(HttpRequest.BodyPublishers.ofString(jsonBody))
                        .build();
                    HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
                    String body = response.body();
                    String transactionId = extractValue(body, "transactionId");
                    
                    SwingUtilities.invokeLater(() -> {
                        JOptionPane.showMessageDialog(SkillBridgeSwing.this, 
                            "✅ Payment Successful!\nTransaction ID: " + transactionId, 
                            "Success", JOptionPane.INFORMATION_MESSAGE);
                        loadDashboardStats();
                        showCourses();
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                    SwingUtilities.invokeLater(() -> 
                        JOptionPane.showMessageDialog(SkillBridgeSwing.this, "Payment failed: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE));
                }
                return null;
            }
        };
        worker.execute();
    }
    
    private void openBookModal(String teacherName, String teacherEmail, double amount) {
        bookDialog = new JDialog(this, "Book a Session", true);
        bookDialog.setSize(400, 350);
        bookDialog.setLocationRelativeTo(this);
        bookDialog.setLayout(new BorderLayout());
        
        JPanel content = new JPanel(new GridBagLayout());
        content.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(8, 0, 8, 0);
        
        content.add(new JLabel("Course: 1-on-1 Session"), gbc);
        bookTeacherNameField = new JTextField(teacherName);
        bookTeacherNameField.setEditable(false);
        gbc.gridy = 1;
        content.add(bookTeacherNameField, gbc);
        
        bookTeacherEmailField = new JTextField(teacherEmail);
        bookTeacherEmailField.setEditable(false);
        gbc.gridy = 2;
        content.add(bookTeacherEmailField, gbc);
        
        bookAmountField = new JTextField("₹" + amount);
        bookAmountField.setEditable(false);
        gbc.gridy = 3;
        content.add(bookAmountField, gbc);
        
        String[] dates = new String[7];
        for (int i = 0; i < 7; i++) {
            java.time.LocalDate date = java.time.LocalDate.now().plusDays(i);
            dates[i] = date.toString();
        }
        bookDateCombo = new JComboBox<>(dates);
        gbc.gridy = 4;
        content.add(bookDateCombo, gbc);
        
        String[] times = {"09:00 AM", "10:00 AM", "11:00 AM", "02:00 PM", "03:00 PM", "04:00 PM", "05:00 PM", "06:00 PM"};
        bookTimeCombo = new JComboBox<>(times);
        gbc.gridy = 5;
        content.add(bookTimeCombo, gbc);
        
        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton confirmBtn = new JButton("Confirm Booking & Pay");
        confirmBtn.addActionListener(e -> {
            currentBookingTeacherEmail = teacherEmail;
            currentBookingAmount = amount;
            createBooking();
            bookDialog.dispose();
        });
        buttonPanel.add(confirmBtn);
        
        JButton cancelBtn = new JButton("Cancel");
        cancelBtn.addActionListener(e -> bookDialog.dispose());
        buttonPanel.add(cancelBtn);
        
        bookDialog.add(content, BorderLayout.CENTER);
        bookDialog.add(buttonPanel, BorderLayout.SOUTH);
        bookDialog.setVisible(true);
    }
    
    private void createBooking() {
        String date = (String) bookDateCombo.getSelectedItem();
        String time = (String) bookTimeCombo.getSelectedItem();
        String transactionId = "TXN" + System.currentTimeMillis() + UUID.randomUUID().toString().substring(0, 6).toUpperCase();
        
        SwingWorker<Void, Void> worker = new SwingWorker<Void, Void>() {
            @Override
            protected Void doInBackground() {
                try {
                    HttpClient client = HttpClient.newHttpClient();
                    String jsonBody = "{\"learnerEmail\":\"" + currentUser.get("email") + "\",\"teacherEmail\":\"" + currentBookingTeacherEmail + 
                                     "\",\"courseId\":1,\"bookingDate\":\"" + date + "\",\"timeSlot\":\"" + time + 
                                     "\",\"amount\":" + currentBookingAmount + ",\"transactionId\":\"" + transactionId + "\"}";
                    HttpRequest request = HttpRequest.newBuilder()
                        .uri(URI.create(BASE_URL + "/api/create-booking"))
                        .header("Content-Type", "application/json")
                        .POST(HttpRequest.BodyPublishers.ofString(jsonBody))
                        .build();
                    client.send(request, HttpResponse.BodyHandlers.ofString());
                    
                    SwingUtilities.invokeLater(() -> {
                        JOptionPane.showMessageDialog(SkillBridgeSwing.this, 
                            "✅ Booking confirmed!\nSession on " + date + " at " + time + "\nTransaction ID: " + transactionId, 
                            "Success", JOptionPane.INFORMATION_MESSAGE);
                        showBookings();
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return null;
            }
        };
        worker.execute();
    }
    
    private void showProfileModal() {
        profileDialog = new JDialog(this, "Edit Profile", true);
        profileDialog.setSize(450, 500);
        profileDialog.setLocationRelativeTo(this);
        profileDialog.setLayout(new BorderLayout());
        
        JPanel content = new JPanel(new GridBagLayout());
        content.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 0, 5, 0);
        
        content.add(new JLabel("Name"), gbc);
        editNameField = new JTextField((String) currentUser.get("name"));
        gbc.gridy = 1;
        content.add(editNameField, gbc);
        
        content.add(new JLabel("Headline"), gbc);
        editHeadlineField = new JTextField();
        gbc.gridy = 2;
        content.add(editHeadlineField, gbc);
        
        content.add(new JLabel("Bio"), gbc);
        editBioArea = new JTextArea(3, 20);
        JScrollPane bioScroll = new JScrollPane(editBioArea);
        gbc.gridy = 3;
        content.add(bioScroll, gbc);
        
        content.add(new JLabel("Address"), gbc);
        editAddressField = new JTextField();
        gbc.gridy = 4;
        content.add(editAddressField, gbc);
        
        content.add(new JLabel("Company"), gbc);
        editCompanyField = new JTextField();
        gbc.gridy = 5;
        content.add(editCompanyField, gbc);
        
        content.add(new JLabel("Position"), gbc);
        editPositionField = new JTextField();
        gbc.gridy = 6;
        content.add(editPositionField, gbc);
        
        content.add(new JLabel("Skills (comma separated)"), gbc);
        editSkillsField = new JTextField();
        gbc.gridy = 7;
        content.add(editSkillsField, gbc);
        
        content.add(new JLabel("Profile Picture (Emoji or URL)"), gbc);
        editProfilePicField = new JTextField("👨‍💻");
        gbc.gridy = 8;
        content.add(editProfilePicField, gbc);
        
        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton saveBtn = new JButton("Save Changes");
        saveBtn.addActionListener(e -> {
            profileDialog.dispose();
            JOptionPane.showMessageDialog(SkillBridgeSwing.this, "Profile updated! (Demo)", "Success", JOptionPane.INFORMATION_MESSAGE);
        });
        buttonPanel.add(saveBtn);
        
        JButton cancelBtn = new JButton("Cancel");
        cancelBtn.addActionListener(e -> profileDialog.dispose());
        buttonPanel.add(cancelBtn);
        
        profileDialog.add(content, BorderLayout.CENTER);
        profileDialog.add(buttonPanel, BorderLayout.SOUTH);
        profileDialog.setVisible(true);
    }
    
    private void showChatbot() {
        chatbotDialog = new JDialog(this, "🤖 AI Learning Assistant", false);
        chatbotDialog.setSize(400, 500);
        chatbotDialog.setLocationRelativeTo(this);
        chatbotDialog.setLayout(new BorderLayout());
        
        chatbotTextArea = new JTextArea();
        chatbotTextArea.setEditable(false);
        chatbotTextArea.setLineWrap(true);
        chatbotTextArea.setWrapStyleWord(true);
        chatbotTextArea.setBackground(new Color(248, 249, 250));
        chatbotTextArea.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        JScrollPane scrollPane = new JScrollPane(chatbotTextArea);
        chatbotDialog.add(scrollPane, BorderLayout.CENTER);
        
        JPanel inputPanel = new JPanel(new BorderLayout());
        chatbotInputField = new JTextField();
        inputPanel.add(chatbotInputField, BorderLayout.CENTER);
        
        JButton sendBtn = new JButton("Send");
        sendBtn.addActionListener(e -> sendBotMessage());
        inputPanel.add(sendBtn, BorderLayout.EAST);
        
        chatbotDialog.add(inputPanel, BorderLayout.SOUTH);
        
        chatbotTextArea.append("👋 Hello! I'm your AI learning assistant. Ask me about courses, teachers, payments, or bookings!\n\n");
        chatbotDialog.setVisible(true);
    }
    
    private void sendBotMessage() {
        String message = chatbotInputField.getText().trim();
        if (message.isEmpty()) return;
        
        chatbotTextArea.append("You: " + message + "\n");
        chatbotInputField.setText("");
        
        SwingWorker<Void, Void> worker = new SwingWorker<Void, Void>() {
            @Override
            protected Void doInBackground() {
                try {
                    HttpClient client = HttpClient.newHttpClient();
                    String jsonBody = "{\"query\":\"" + message + "\",\"email\":\"" + currentUser.get("email") + "\"}";
                    HttpRequest request = HttpRequest.newBuilder()
                        .uri(URI.create(BASE_URL + "/api/chatbot"))
                        .header("Content-Type", "application/json")
                        .POST(HttpRequest.BodyPublishers.ofString(jsonBody))
                        .build();
                    HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
                    String body = response.body();
                    String botResponse = extractValue(body, "response");
                    
                    SwingUtilities.invokeLater(() -> {
                        chatbotTextArea.append("🤖 Bot: " + botResponse + "\n\n");
                        chatbotTextArea.setCaretPosition(chatbotTextArea.getDocument().getLength());
                    });
                } catch (Exception e) {
                    SwingUtilities.invokeLater(() -> 
                        chatbotTextArea.append("🤖 Bot: Sorry, I'm having trouble connecting. Please try again.\n\n"));
                }
                return null;
            }
        };
        worker.execute();
    }
    
    private void logout() {
        currentUser.clear();
        cardLayout.show(mainPanel, "auth");
        loginEmailField.setText("learner@skillbridge.com");
        loginPasswordField.setText("learner123");
    }
    
    private JPanel createCourseCard() {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(224, 224, 224)),
            BorderFactory.createEmptyBorder(16, 16, 16, 16)
        ));
        return card;
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                e.printStackTrace();
            }
            new SkillBridgeSwing().setVisible(true);
        });
    }
}